#ifndef _SDF_H_
#define _SDF_H_ 1


#include <stdint.h>


#ifdef __cplusplus
extern "C"{
#endif


/*类型定义*/
typedef char          SGD_CHAR;
typedef int8_t        SGD_INT8;
typedef int16_t       SGD_INT16;
typedef int32_t       SGD_INT32;
typedef int64_t       SGD_INT64;
typedef unsigned char SGD_UCHAR;
typedef uint8_t       SGD_UINT8;
typedef uint16_t      SGD_UINT16;
typedef uint32_t      SGD_UINT32;
typedef uint64_t      SGD_UINT64;
typedef unsigned int  SGD_RV;
typedef void*         SGD_HANDLE;

/*设备信息结构体*/
typedef struct DeviceInfo_st {
	unsigned char IssuerName[40];
	unsigned char DeviceName[16];
	unsigned char DeviceSerial[16];
	unsigned int  DeviceVersion;
	unsigned int  StandardVersion;
	unsigned int  AsymAlgAbility[2];
	unsigned int  SymAlgAbility;
	unsigned int  HashAlgAbility;
	unsigned int  BufferSize;
} DEVICEINFO;



/*ECC算法*/
#define ECCref_MAX_BITS 256
#define ECCref_MAX_LEN ((ECCref_MAX_BITS+7) / 8)
#define ECCref_MAX_CIPHER_LEN 2048

#define ECCref_MAX_PLAINTEXT_LEN_22 128
	
/*ECC 公钥结构体*/
typedef struct ECCrefPublicKey_st {
	unsigned int  bits;
	unsigned char x[ECCref_MAX_LEN];
	unsigned char y[ECCref_MAX_LEN];
} ECCrefPublicKey;

/*ECC 私钥结构体*/
typedef struct ECCrefPrivateKey_st {
	unsigned int  bits;
	unsigned char D[ECCref_MAX_LEN];
} ECCrefPrivateKey;

/*ECC 密文*/
typedef struct ECCCipher_st {
	unsigned int  clength; // C����Ч����
	unsigned char x[ECCref_MAX_LEN];
	unsigned char y[ECCref_MAX_LEN];
	unsigned char C[ECCref_MAX_CIPHER_LEN];
	unsigned char M[ECCref_MAX_LEN];
} ECCCipher;

/*ECC 签名值*/
typedef struct ECCSignature_st {
	unsigned char r[ECCref_MAX_LEN];
	unsigned char s[ECCref_MAX_LEN];
} ECCSignature;

#define ECC_MAX_XCOORDINATE_BITS_LEN 512    //ECC算法X座标的最大长度                                                               
#define ECC_MAX_YCOORDINATE_BITS_LEN 512    //ECC算法Y座标的最大长度
/*ECC公钥*/
typedef struct Struct_ECCPUBLICKEYBLOB{
	SGD_UINT32	BitLen;
	SGD_UCHAR	XCoordinate[ECC_MAX_XCOORDINATE_BITS_LEN/8];//仅使用用前32字节
	SGD_UCHAR	YCoordinate[ECC_MAX_YCOORDINATE_BITS_LEN/8];//仅使用用前32字节
}ECCPUBLICKEYBLOB, *PECCPUBLICKEYBLOB;
	
typedef struct Struct_ECCCIPHERBLOB{
	SGD_UCHAR	XCoordinate[ECC_MAX_XCOORDINATE_BITS_LEN/8]; //仅使用用前32字节
	SGD_UCHAR	YCoordinate[ECC_MAX_XCOORDINATE_BITS_LEN/8]; //仅使用用前32字节
	SGD_UCHAR	HASH[32]; 
	SGD_UINT32	CipherLen;
	SGD_UCHAR	Cipher[1]; 
} ECCCIPHERBLOB, *PECCCIPHERBLOB;
	
/*ECC加密密钥对保护结构*/
typedef struct SKF_ENVELOPEDKEYBLOB{
	SGD_UINT32 Version;                  // 当前版本为1
	SGD_UINT32 ulSymmAlgID;              // 对称算法标识，限定SM4_ECB模式
	SGD_UINT32 ulBits;					// 加密密钥对的密钥位长度，固定为256
	SGD_UCHAR cbEncryptedPriKey[64];     // 加密密钥对私钥的密文，仅使用用前32字节
	ECCPUBLICKEYBLOB PubKey;        // 加密密钥对的公钥
	ECCCIPHERBLOB ECCCipherBlob;    // 用签名公钥加密的对称密钥密文
}ENVELOPEDKEYBLOB, *PENVELOPEDKEYBLOB;


/*算法模式*/
#define SGD_SM1_ECB 0x00000101
#define SGD_SM1_CBC 0x00000102
#define SGD_SM1_CFB 0x00000104
#define SGD_SM1_OFB 0x00000108
#define SGD_SM1_MAC 0x00000110
#define SGD_SM1_CTR 0x00000120
#define SGD_IPSEC_SM1	0x00000121
#define SGD_IPSEC_SM4	0x00000122

#define SGD_SSF33_ECB 0x00000201
#define SGD_SSF33_CBC 0x00000202
#define SGD_SSF33_CFB 0x00000204
#define SGD_SSF33_OFB 0x00000208
#define SGD_SSF33_MAC 0x00000210
#define SGD_SSF33_CTR 0x00000220

#define SGD_AES_ECB 0x00000401
#define SGD_AES_CBC 0x00000402
#define SGD_AES_CFB 0x00000404
#define SGD_AES_OFB 0x00000408
#define SGD_AES_MAC 0x00000410
#define SGD_AES_CTR 0x00000420

#define SGD_3DES_ECB 0x00000801
#define SGD_3DES_CBC 0x00000802
#define SGD_3DES_CFB 0x00000804
#define SGD_3DES_OFB 0x00000808
#define SGD_3DES_MAC 0x00000810
#define SGD_3DES_CTR 0x00000820

#define SGD_SMS4_ECB 0x00002001
#define SGD_SMS4_CBC 0x00002002
#define SGD_SMS4_CFB 0x00002004
#define SGD_SMS4_OFB 0x00002008
#define SGD_SMS4_MAC 0x00002010
#define SGD_SMS4_CTR 0x00002020

#define SGD_SM4_ECB 0x00002001
#define SGD_SM4_CBC 0x00002002
#define SGD_SM4_CFB 0x00002004
#define SGD_SM4_OFB 0x00002008
#define SGD_SM4_MAC 0x00002010
#define SGD_SM4_CTR 0x00002020

#define SGD_DES_ECB 0x00004001
#define SGD_DES_CBC 0x00004002
#define SGD_DES_CFB 0x00004004
#define SGD_DES_OFB 0x00004008
#define SGD_DES_MAC 0x00004010
#define SGD_DES_CTR 0x00004020

#define SGD_RSA      0x00010000
#define SGD_RSA_SIGN 0x00010100
#define SGD_RSA_ENC  0x00010200
#define SGD_SM2_1    0x00020100 //椭圆曲线签名算法
#define SGD_SM2_2    0x00020200 //椭圆曲线密钥交换协议
#define SGD_SM2_3    0x00020400 //椭圆曲线加密算法 

#define SGD_SM3			0x00000000
#define SGD_SHA_160		0x00000001
#define SGD_SHA_224		0x00000002
#define SGD_SHA_256		0x00000003
#define SGD_SHA_384		0x00000004
#define SGD_SHA_512		0x00000005
	
//对称密钥类型
#define SGD_KEY_TYPE_ROOTKEY			0x01	//根密钥
#define SGD_KEY_TYPE_KPK				0x02	//密钥保护密钥
#define SGD_KEY_TYPE_FILEKEY			0x04	//文件维护密钥
#define SGD_KEY_TYPE_SESSIONKEY 		0x08	//会话密钥

//非对称密钥类型
#define SGD_KEY_TYPE_SM2			0x01		//SM2密钥对
#define SGD_KEY_TYPE_RSA1024		0x02		//RSA1024密钥对
#define SGD_KEY_TYPE_RSA2048		0x04		//RSA2048密钥对
#define SGD_KEY_TYPE_ECC			0x08		//ECC密钥对

//非对称密钥的用途
#define SGD_KEY_USAGE_ENCRYPTION	0x01		//用于 加密解密
#define SGD_KEY_USAGE_SIGN			0x02		//用于 签名验签
#define SGD_KEY_USAGE_EXCHANGE		0x04		//用于 密钥交换
	
//导出、导入非对称密钥时，指定操作内容标识
#define SGD_Asymmetric_PUBKEY		0x01		//用于指定导入导出公钥
#define SGD_Asymmetric_PRIKEY		0x02		//用于指定导入导出私钥
#define SGD_Asymmetric_KEYPAIR		0x03		//用于指定导入导出密钥对

/*错误码定义*/
#define SDR_OK               0x0 						/*成功*/
#define SDR_BASE             0x01000000
#define SDR_UNKNOWERR        (SDR_BASE + 0x00000001)    /*未知错误*/
#define SDR_NOTSUPPORT       (SDR_BASE + 0x00000002)    /*不支持*/
#define SDR_COMMFAIL         (SDR_BASE + 0x00000003)    /*ͨAPDU命令返回失败*/
#define SDR_HARDFAIL         (SDR_BASE + 0x00000004)    /*硬件错误*/
#define SDR_OPENDEVICE       (SDR_BASE + 0x00000005)    /*打开设备失败*/
#define SDR_OPENSESSION      (SDR_BASE + 0x00000006)    /*打开会话失败*/
#define SDR_ALGNOTSUPPORT    (SDR_BASE + 0x00000009)    /*算法模式不支持*/
#define SDR_BUFFER_TOO_SMALL (SDR_BASE + 0x00000016)    /*缓存不够*/
#define SDR_INVALIDPARAMERR  (SDR_BASE + 0x00000017)  	/*参数错误*/
#define SDR_MALLOCFAILED	 (SDR_BASE + 0x00000018)	/*malloc失败*/
#define SDR_MUTEXERR		 (SDR_BASE + 0x00000019)	/*mutex失败*/
#define SDR_WNG4_GPIOERR	 (SDR_BASE + 0x00000020)	/*标识GPIO模拟采集WNG故障*/
#define SDR_WNG4_SPIERR	 	 (SDR_BASE + 0x00000021)	/*标识SPI采集WNG故障*/
#define SDR_WNG4_BOTHERR	 (SDR_BASE + 0x00000022)	/*两路WNG4故障*/
#define SDR_KERNEL_COPY	 	 (SDR_BASE + 0x00000023)	/*内核中copy失败*/
#define SDR_HASHINIT_ERR	 (SDR_BASE + 0x00000024)	/*未进行Hash初始化*/
#define SDR_APDUFAIL 		 (SDR_BASE + 0x00000025)	/*APDU指令失败，可理解为操作执行失败*/
#define SDR_GETDEVLISTFAIL 	 (SDR_BASE + 0x00000026)	/*获取设备列表失败*/
#define SDR_GETDEVDESCFAIL 	 (SDR_BASE + 0x00000027)	/*获取设备描述信息失败*/
#define SDR_PARSEENDPOINT 	 (SDR_BASE + 0x00000028)	/*端点解析失败*/

/*
功能:枚举设备，返回设备名称的链表
参数：
	DevNamelist		输出，存放设备名称的缓存，当枚举到多个设备时，各设备名称以‘\0’分割。一般每个设备的名称占10个字节，请分配足够的空间。
	DevNameListLen	输入/输出，输入时表示DevNamelist空间的长度，输出时返回DevNamelist实际需要的空间大小。
	DevNum			输出，枚举到的设备数量。
返回值:
	返回0成功,其他见错误码
*/
SGD_RV SDF_EnumDev(SGD_UCHAR *DevNamelist, SGD_UINT32 *pDevNameListLen, SGD_UINT32 *DevNum);
	
/*
功能:通过名称连接设备.返回设备句柄
参数：
	DevName			输入,设备名称。
	phDeviceHandle	输出,返回设备句柄。
返回值：
	返回0成功,其他值见错误码
*/
SGD_RV SDF_ConnectDevicesByName(SGD_UCHAR *DevName, SGD_HANDLE *phDeviceHandle);

/*
功能:连接设备,返回设备句柄;
参数:
	phDeviceHandle		输出, 设备句柄;
返回值:
	返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_OpenDevice(SGD_HANDLE *phDeviceHandle);
	
/*
功能:断开连接,销毁句柄.
参数:
	hDeviceHandle		输入,设备句柄;
返回值:
	返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_CloseDevice(SGD_HANDLE hDeviceHandle);
	
/*
功能:打开一个会话,返回会话句柄.Session是SDK内部封装的一个类,内部实现各功能接口.
参数:
	hDeviceHandle		输入,设备句柄.
	phSessionHandle		输出,返回的会话句柄.
返回值:
	返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_OpenSession(SGD_HANDLE hDeviceHandle, SGD_HANDLE *phSessionHandle);
	
/*
功能:关闭会话,销毁会话句柄
参数:
	hSessionHandle		输入,要关闭的会话句柄.
返回值:
	返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_CloseSession(SGD_HANDLE hSessionHandle);
	
/*
功能:生成随机数
参数:
	hSessionHandle		输入,会话句柄;
	pOutRand			输出,随机数;
	ulRandLen			输入,要生成的随机数的长度,取值范围8/16/256;
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_GenerateRandom(SGD_HANDLE hSessionHandle, SGD_UCHAR* pOutRand, SGD_UINT32 ulRandLen);
	
/*
功能:外部认证，通过调用此接口获取相应的权限
参数:
	hSessionHandle		输入,会话句柄;
	ucKeyType			输入,认证的密钥类型，取值范围：
								SGD_KEY_TYPE_ROOTKEY  	根密钥，权限用于更新根密钥、密钥保护密钥、文件密钥。
								SGD_KEY_TYPE_KPK		密钥保护密钥，权限用于导入和导出各非对称密钥。
								SGD_KEY_TYPE_FILEKEY	文件密钥，权限用于控制二进制区的读写。
	pucAuthenData		输入,认证数据，计算方式，先获取16字节随机数，使用ucKeyType表示的密钥对随机数做SM4算法ECB模式加密得到的密文。
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_ExternalAuthen(SGD_HANDLE hSessionHandle, SGD_UCHAR ucKeyType, SGD_UCHAR* pucAuthenData);
	
/*
功能:设置设备序列号(SN), 方便用户管理设备，执行此操作前需进行根密钥的外部认证。
参数:
	hSessionHandle		输入,会话句柄;
	pucDevSN			输入,SN数据；
	uiDevSNLen			输入,SN数据长度，取值范围 6~32字节。
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_InstallDeviceSN(SGD_HANDLE hSessionHandle, SGD_UCHAR* pucDevSN, SGD_UINT32 uiDevSNLen);

/*
功能:获取设备序列号(SN)
参数:
	hSessionHandle		输入,会话句柄;
	pucDevSN			输出,返回设备序列号；
	puiDevSNLen			输入/输出, 输入时表示pucDevSN缓冲区长度，输出时表示获取到的设备序列号的实际长度。
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_GetDeviceSN(SGD_HANDLE hSessionHandle, SGD_UCHAR *pucDevSN, SGD_UINT32 *puiDevSNLen);
	
/*
功能:获取芯片COS版本
参数:
	hSessionHandle		输入,会话句柄.
	pucCosVersion		输出,返回的cos版本信息, ASCII码形式，分配空间不小于4字节.
返回值:
	返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_GetCosVersion(SGD_HANDLE hSessionHandle, SGD_UCHAR* pucCosVersion);
	
/*
功能:获取芯片ID
参数:
	hSessionHandle		输入,会话句柄;
	pucChipID			输出,返回芯片ID。
	puiChipIDLen		输入/输出, 输入时表示 pucChipID 缓冲区长度，输出时表示获取到的芯片ID的实际长度。
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_GetChipID(SGD_HANDLE hSessionHandle, SGD_UCHAR *pucChipID, SGD_UINT32 *puiChipIDLen);
	
/*
功能:获取芯片内的密钥列表
参数:
	hSessionHandle		输入,会话句柄;
	pucKeyList			输出,返回密钥列表，表示的密钥信息如下：
							80H + 根密钥存在标识（1字节，00 = 不存在，01 = 存在）
							81H + 密钥保护密钥存在标识（1字节，00 = 不存在，01 = 存在）
							82H + 文件密钥存在标识（1字节，00 = 不存在，01 = 存在）
							83H + 会话密钥存在标识（16字节，对应ID = 00 - 0F，值=00标识不存在，=01表示存在）
							84H + SM2密钥标识（16字节，对应ID=00-0F，00=不存在，01=私钥，02=公钥，03=密钥对）
							85H + RSA密钥标识（32字节，对应ID=00-1F，00=不存在，01=公钥存在，02=私钥D存在，03=密钥对ND存在，04=私钥CRT存在，05=密钥对CRT存在）
							86H + ECC密钥标识（16字节，对应ID=00-0F，00=不存在，01=私钥，02=私钥，03=密钥对）
	puiKeyListLen		输入/输出, 输入时表示 pucKeyList 缓冲区长度，输出时表示获取到的密钥列表的实际长度，一般返回90字节内容。
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_GetKeyList(SGD_HANDLE hSessionHandle, SGD_UCHAR *pucKeyList, SGD_UINT32 *puiKeyListLen);
	
/*
功能:导入/更新管理类密钥，包括 根密钥、密钥保护密钥、文件密钥，执行此操作前需进行根密钥的外部认证。
参数:
	hSessionHandle		输入,会话句柄;
	ucKeyType			输入,密钥类型，取值范围：
								SGD_KEY_TYPE_ROOTKEY  	根密钥，权限用于更新根密钥、密钥保护密钥、文件密钥。
								SGD_KEY_TYPE_KPK		密钥保护密钥，权限用于导入和导出各非对称密钥。
								SGD_KEY_TYPE_FILEKEY	文件密钥，权限用于控制二进制区的读写。
	pucKeyData			输入,密钥数据，长度为16字节。
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_ImportManagerialKey(SGD_HANDLE hSessionHandle, SGD_UCHAR ucKeyType, SGD_UCHAR* pucKeyData);
	
/*
功能:设置芯片内二进制数据区的读写权限，执行此操作前需进行文件密钥的外部认证。
参数:
	hSessionHandle		输入,会话句柄;
	ucReadPermission	输入,读权限，0x00:任意读； 0x01:对文件密钥进行外部认证后可读； 0xFF:禁止读。
	ucWritePermission	输入,写权限，0x00:任意写； 0x01:对文件密钥进行外部认证后可写； 0xFF:禁止写。
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_ConfigDataAreaPermission(SGD_HANDLE hSessionHandle, SGD_UCHAR ucReadPermission, SGD_UCHAR ucWritePermission);
	
/*
功能:读取二进制数据,芯片中存在一个可读写的二进制区域,大小为16k字节.
参数:
	hSessionHandle		输入,会话句柄;
	pOutData			输出,读出的二进制数据;
	OutDataLen			输入,要读取的长度;
	uiOffset			输入,偏移量(0~16383),此参数控制读写位置;
返回值:
	返回0成功,其他值见错误码.
*/	
SGD_RV SDF_ReadBinary(SGD_HANDLE hSessionHandle, SGD_UCHAR *pOutData, SGD_UINT32 OutDataLen, SGD_UINT32 uiOffset);
	
/*
功能:写入(更新)二进制数据,芯片中存在一个可读写的二进制区域,大小为16k字节.
参数:
	hSessionHandle		输入,会话句柄;
	pInData				输出,要写入的二进制数据;
	uiInDataLen			输入,要写入的长度;
	uiOffset			输入,偏移量(0~16383),此参数控制读写位置;
返回值:
	返回0成功,其他值见错误码.
*/	
SGD_RV SDF_WriteBinary(SGD_HANDLE hSessionHandle, SGD_UCHAR *pInData, SGD_UINT32 uiInDataLen, SGD_UINT32 uiOffset);
	
/*
功能：导入/更新会话密钥,若指定索引下密钥已存在，则新导入密钥将覆盖原密钥，会话密钥掉电丢失。
参数：
	hSessionHandle		输入，会话句柄;
	uiKeyInd			输入，密钥索引值，取值范围0x00——0x0F,支持16组会话密钥;
	pucKey				输入，缓冲区指针，用于存放输入的会话密钥；
	uiKeyLength			输入，输入的密钥长度；
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_ImportSessionKey(SGD_HANDLE hSessionHandle, SGD_UINT32 uiKeyInd, SGD_UCHAR *pucKey, SGD_UINT32 uiKeyLength);	
	
/*
功能：根据索引删除指定会话密钥。
参数：
	hSessionHandle		输入，会话句柄;
	uiKeyInd			输入，密钥索引值，取值范围0x00——0x0F;
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_DestroySessionKey(SGD_HANDLE hSessionHandle, SGD_UINT32 uiKeyInd);
	
/*
功能:对称算法加密
参数:
	hSessionHandle		输入,会话句柄.
	pucKey				输入,加密使用的密钥,当此参数为空时,使用参数uiKeyInd指定的KEY内保存的密钥.
	uiKeyLength			输入，输入的密钥长度，当此参数等于0时,使用参数uiKeyInd指定的KEY内保存的密钥；
	uiKeyInd			输入,密钥索引, 索引范围0x00~0x0F，当参数pucKey为空或uiKeyLength等于0时，此参数才有效,否则，加密时使用参数pucKey传入的数据作为密钥.
	uiAlgID				输入,加密模式,取值 SGD_SM1_ECB/SGD_SM1_CBC/SGD_SM4_ECB/SGD_SM4_CBC/SGD_AES_ECB/SGD_AES_CBC.
	pucIV				输入/输出,初始向量, CBC模式使用, ECB模式可传NULL.
	pucData				输入,要加密的数据.
	uiDataLength		输入,要加密的数据的长度,必须为16的整数倍,且最大4080字节.
	pucEncData			输出,加密后的数据.
	puiEncDataLength	输入/输出,输入是表示pucEncData空间的大小,输出时表示加密后的数据的长度.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_Encrypt(SGD_HANDLE hSessionHandle, SGD_UCHAR *pucKey, SGD_UINT32 uiKeyLength, SGD_UINT32 uiKeyInd, SGD_UINT32 uiAlgID, SGD_UCHAR *pucIV, SGD_UCHAR *pucData, SGD_UINT32 uiDataLength, SGD_UCHAR *pucEncData, SGD_UINT32 *puiEncDataLength);
	
/*
功能描述:对称算法解密
参数:
	hSessionHandle		输入,会话句柄.
	pucKey				输入,解密使用的密钥,当此参数为空时,使用参数uiKeyInd指定的KEY内保存的密钥.
	uiKeyLength			输入，输入的密钥长度，当此参数等于0时,使用参数uiKeyInd指定的KEY内保存的密钥；
	uiKeyInd			输入,密钥索引, 索引范围0x00~0x0F，当参数pucKey为空或uiKeyLength等于0时，此参数才有效,否则，解密时使用参数pucKey传入的数据作为密钥.
	uiAlgID				输入,加密模式,取值 SGD_SM1_ECB/SGD_SM1_CBC/SGD_SM4_ECB/SGD_SM4_CBC/SGD_AES_ECB/SGD_AES_CBC.
	pucIV				输入/输出,初始向量,  CBC模式使用, ECB模式可传NULL.
	pucEncData			输入,要解密的数据.
	uiEncDataLength		输入,要解密的数据的长度,必须为16的整数倍,且最大4080字节.
	pucData				输出,解密后的数据.
	puiDataLength		输入/输出,输入是表示pucData的空间大小,输出时表示解密后的数据的长度.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_Decrypt(SGD_HANDLE hSessionHandle, SGD_UCHAR *pucKey, SGD_UINT32 uiKeyLength, SGD_UINT32 uiKeyInd, SGD_UINT32 uiAlgID, SGD_UCHAR *pucIV, SGD_UCHAR *pucEncData, SGD_UINT32 uiEncDataLength, SGD_UCHAR *pucData, SGD_UINT32 *puiDataLength);
	
/*
功能描述:IPSEC数据加密
参数:
	hSessionHandle		输入,会话句柄.
	pucKey				输入,加密用密钥.
	uiAlgID				输入,加密模式,取值 SGD_IPSEC_SM1/SGD_IPSEC_SM4.
	HMACKEY				输入,计算HMAC的密钥.
	HMACKEYLEN			输入,HMAC的密钥长度
	pucData				输入,要进行加密计算的数据,包含IPSEC头，除去IPSEC头的数据长度必须为16的整数倍.
	uiDataLen			输入,pucData的长度,且最大4048字节.
	uiOffset			输入,对pucData加密时的偏移长度，可以理解为pucData中IPSEC头的长度。
	pucOutData			输出,返回的“密文+HMAC”数据.
	puiOutDataLen		输入/输出,输入是表示pucOutData的空间大小,输出时表示输出数据的实际长度.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_Encrypt_IPSEC(SGD_HANDLE hSessionHandle, SGD_UINT32 uiAlgID, SGD_UCHAR *pucKey, SGD_UCHAR *HMACKEY, SGD_UINT32 HMACKEYLEN, SGD_UCHAR *pucData, SGD_UINT32 uiDataLen, SGD_UINT32 uiOffset, SGD_UCHAR *pucOutData, SGD_UINT32 *puiOutDataLen);
	
/*
功能描述:IPSEC数据解密
参数:
	hSessionHandle		输入,会话句柄.
	pucKey				输入,解密用密钥.
	uiAlgID				输入,加密模式,取值 SGD_IPSEC_SM1/SGD_IPSEC_SM4.
	HMACKEY				输入,计算HMAC的密钥.
	pucEncData			输入,要进行解密结算的数据,包含IPSEC头，除去IPSEC头的数据长度必须为16的整数倍.
	uiEncDataLen		输入,pucEncData的长度,且最大4048字节.
	uiOffset			输入,对pucEncData解密时的偏移长度，可以理解为pucEncData中IPSEC头的长度。
	pucOutData			输出,返回的“明文+HMAC”数据。
	puiOutDataLen		输入/输出,输入是表示pucOutData的空间大小,输出时表示输出数据的实际长度.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_Decrypt_IPSEC(SGD_HANDLE hSessionHandle, SGD_UINT32 uiAlgID, SGD_UCHAR *pucKey, SGD_UCHAR *HMACKEY, SGD_UINT32 HMACKEYLEN, SGD_UCHAR *pucEncData, SGD_UINT32 uiEncDataLen, SGD_UINT32 uiOffset, SGD_UCHAR *pucOutData, SGD_UINT32 *puiOutDataLen);

	
/*
描述:请求密码设备产生指定类型和模长的密钥对,支持的密钥对类型包括 SM2、RSA1024、RSA2048、ECC，若指定ID的密钥对已存在，则新生成的密钥对将覆盖原密钥对。
参数:
	hSessionHandle		输入,与设备建立的会话句柄。
	ucKeyType			输入,指定产生的密钥类型，取值范围：
							SGD_KEY_TYPE_SM2		//SM2密钥对
							SGD_KEY_TYPE_RSA1024	//RSA1024密钥对
							SGD_KEY_TYPE_RSA2048	//RSA2048密钥对
							SGD_KEY_TYPE_ECC		//ECC密钥对
	uiKeyInd			输入,密钥索引值，取值范围0x00~0x0F;
	ucUsage				输入,指定密钥用途，取值：
							SGD_KEY_USAGE_ENCRYPTION	//用于 加密解密
							SGD_KEY_USAGE_SIGN			//用于 签名验签
							SGD_KEY_USAGE_EXCHANGE		//用于 密钥交换
							ucUsage的取值也可以是以上取值的或操作， 如 ucUsage = SGD_KEY_USAGE_ENCRYPTION | SGD_KEY_USAGE_SIGN； 表示生成的密钥即可用于加密解密，也可用于签名验签。
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_GenerateKeyPair(SGD_HANDLE hSessionHandle, SGD_UCHAR ucKeyType, SGD_UINT32 uiKeyInd, SGD_UCHAR ucUsage);

/*
功能描述:导出非对称密钥,可分别导出公钥、私钥、密钥对，明文返回，执行此操作前需进行密钥保护密钥的外部认证。
参数:
	hSessionHandle		输入,会话句柄.
	ucKeyType			输入,指定导出的密钥类型，取值范围：
							SGD_KEY_TYPE_SM2		//SM2密钥对
							SGD_KEY_TYPE_RSA1024	//RSA1024密钥对
							SGD_KEY_TYPE_RSA2048	//RSA2048密钥对
							SGD_KEY_TYPE_ECC		//ECC密钥对
	uiKeyInd			输入,密钥索引值，取值范围0x00~0x0F.
	ucKeyContent		输入,指定要导出的密钥具体内容，取值：
							SGD_Asymmetric_PUBKEY	//用于指定导入导出公钥
							SGD_Asymmetric_PRIKEY	//用于指定导入导出私钥
							SGD_Asymmetric_KEYPAIR	//用于指定导入导出密钥对
	pucOutData			输出，返回的密钥内容，具体可分为以下几种情况：
							ECC/SM2公钥 = 64字节
							ECC/SM2私钥 = 32字节
							ECC/SM2密钥对 = 公钥 || 私钥，共96字节
							RSA1024公钥 = 公钥指数4字节 || 公钥模128字节
							RSA1024私钥CRT = 320字节 (p||q||Dp||Dq||i)
							RSA1024密钥对CRT = 452字节 （E + N + CRT）
							RSA2048公钥 = 公钥指数4字节 || 公钥模256字节
							RSA2048私钥CRT = 640字节(p||q||Dp||Dq||i)
							RSA2048密钥对CRT = 900字节 (E + N + CRT)
	puiOutDataLen		输入/输出，输入时表示 pucOutData 的空间大小， 输出时表示返回内容的实际大小。
返回值:
	返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_ExportAsymmetricKey(SGD_HANDLE hSessionHandle, SGD_CHAR ucKeyType, SGD_UINT32 uiKeyInd, SGD_CHAR ucKeyContent, SGD_CHAR * pucOutData, SGD_UINT32* puiOutDataLen);
	
/*
功能描述:导入非对称密钥,可分别导入公钥、私钥、密钥对，明文导入，若指定位置已存在密钥，则覆盖原内容，执行此操作前需进行密钥保护密钥的外部认证。
参数:
	hSessionHandle		输入,会话句柄.
	ucKeyType			输入,指定导出的密钥类型，取值范围：
							SGD_KEY_TYPE_SM2		//SM2密钥对
							SGD_KEY_TYPE_RSA1024	//RSA1024密钥对
							SGD_KEY_TYPE_RSA2048	//RSA2048密钥对
							SGD_KEY_TYPE_ECC		//ECC密钥对
	uiKeyInd			输入,密钥索引值，取值范围0x00~0x0F.
	ucKeyContent		输入,指定要导出的密钥具体内容，取值：
							SGD_Asymmetric_PUBKEY	//用于指定导入导出公钥
							SGD_Asymmetric_PRIKEY	//用于指定导入导出私钥
							SGD_Asymmetric_KEYPAIR	//用于指定导入导出密钥对
	ucUsage				输入,指定密钥用途，取值：
							SGD_KEY_USAGE_ENCRYPTION	//用于 加密解密
							SGD_KEY_USAGE_SIGN			//用于 签名验签
							SGD_KEY_USAGE_EXCHANGE		//用于 密钥交换
							ucUsage的取值也可以是以上取值的或操作， 如 ucUsage = SGD_KEY_USAGE_ENCRYPTION | SGD_KEY_USAGE_SIGN； 表示生成的密钥即可用于加密解密，也可用于签名验签。
	pucInData			输入，返回的密钥内容，具体可分为以下几种情况：
							ECC/SM2公钥 = 64字节
							ECC/SM2私钥 = 32字节
							ECC/SM2密钥对 = 公钥 || 私钥，共96字节
							RSA1024公钥 = 公钥指数4字节 || 公钥模128字节
							RSA1024私钥CRT = 320字节(p||q||Dp||Dq||i)
							RSA1024密钥对CRT = 452字节
							RSA2048公钥 = 公钥指数4字节 || 公钥模256字节
							RSA2048私钥CRT = 640字节(p||q||Dp||Dq||i)
							RSA2048密钥对CRT = 900字节
	uiInDataLen			输入，表示 pucInData 的长度。
返回值:
	返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_ImportAsymmetricKey(SGD_HANDLE hSessionHandle, SGD_CHAR ucKeyType, SGD_UINT32 uiKeyInd, SGD_CHAR ucKeyContent, SGD_UCHAR ucUsage, SGD_CHAR * pucInData, SGD_UINT32 uiInDataLen);
	
/*
功能: ECC加密
参数:
	hSessionHandle		输入,会话句柄.
	uiIPKIndex			输入,索引值，取值范围0x00~0x0F,需保证索引值对应位置存在密钥；
	uiAlgID				输入,算法类型，此参数暂不使用，接口固定使用ECC算法.
	pucData				输入,要加密的数据
	uiDataLength		输入,要加密的数据的长度, 最大2048字节.
	pucEncData			输出,加密后的数据.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_InternalEncrypt_ECC(SGD_HANDLE hSessionHandle, SGD_UINT32 uiIPKIndex, SGD_UINT32 uiAlgID, SGD_UCHAR *pucData, SGD_UINT32 uiDataLength, ECCCipher *pucEncData);
	
/*
功能:ECC解密
参数:
	参数:
	hSessionHandle		输入,会话句柄.
	uiISKIndex			输入,索引值.取值范围0x00~0x0F,需保证索引值对应位置存在密钥；
	uiAlgID				输入,算法类型，此参数暂不使用，接口固定使用ECC算法.
	pucEncData			输入,要解密的数据
	pucData				输出,解密后的数据
	puiDataLength		输入/输出,输入时表示pucData的空间大小, 输出时表示解密后数据的长度.

返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_InternalDecrypt_ECC(SGD_HANDLE hSessionHandle, SGD_UINT32 uiISKIndex, SGD_UINT32 uiAlgID, ECCCipher *pucEncData, SGD_UCHAR *pucData, SGD_UINT32 *puiDataLength);
	
/*
功能: ECC签名
参数:
	hSessionHandle		输入,会话句柄.
	uiISKIndex			输入,索引值，取值范围0x00~0x0F,需保证索引值对应位置存在密钥；
	pucHashData			输入,32字节的Hash结果数据.
	uiHashDataLength	输入,pucHashData的长度,固定为32.
	pucSignature		输出,签名值,长度为64字节.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_InternalSign_ECC(SGD_HANDLE hSessionHandle, SGD_UINT32 uiISKIndex, SGD_UCHAR *pucHashData, SGD_UINT32 uiHashDataLength, ECCSignature *pucSignature);
	
/*
功能描述: ECC验签
参数:
	hSessionHandle		输入,会话句柄.
	uiISKIndex			输入,索引值，取值范围0x00~0x0F,需保证索引值对应位置存在密钥；
	pucHashData			输入,32字节Hash结果数据.
	uiHashDataLength	输入,pucHashData的长度, 固定为32.
	pucSignature		输入,64字节的签名值.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_InternalVerify_ECC(SGD_HANDLE hSessionHandle, SGD_UINT32 uiISKIndex, SGD_UCHAR *pucHashData, SGD_UINT32 uiHashDataLength, ECCSignature *pucSignature);
	
/*
外部密钥ECC公钥加密
描述:使用外部ECC公钥对数据进行加密运算
参数:
	hSessionHandle		输入,与设备建立的会话句柄。
	uiAlgID				输入,算法类型，此参数暂不使用，接口固定使用ECC算法.
	pucPublicKey		输入,外部ECC公钥结构.
	pucDataInput		输入,缓冲区指针,用于存放外部输入的数据.
	uiInputLength		输入,输入的数据长度,最大2048字节.
	pucEncData			输出,缓冲区指针,用于存放输出的数据密文.
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_ExternalEncrypt_ECC(SGD_HANDLE hSessionHandle, SGD_UINT32 uiAlgID, ECCrefPublicKey *pucPublicKey, SGD_UCHAR *pucDataInput, SGD_UINT32 uiInputLength, ECCCipher *pucEncData);	
		
/*
外部密钥ECC私钥解密
描述:使用外部ECC私钥进行解密运算
参数:
	hSessionHandle		输入,与设备建立的会话句柄。
	uiAlgID				输入,算法类型，此参数暂不使用，接口固定使用ECC算法.
	pucPrivateKey		输入,外部ECC私钥结构.
	pucEncData			输入,缓冲区指针,用于存放输入的数据密文.
	pucDataOutput		输出,缓冲区指针,用于存放输出的数据明文.
	puiOutputLength		输入/输出,入参表示pucDataOutput的空间大小,出参表示输出的数据明文长度.
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_ExternalDecrypt_ECC(SGD_HANDLE hSessionHandle, SGD_UINT32 uiAlgID, ECCrefPrivateKey *pucPrivateKey, ECCCipher *pucEncData, SGD_UCHAR *pucDataOutput, SGD_UINT32 *puiOutputLength);	
	
/*
外部密钥ECC签名
描述:使用外部ECC私钥对数据进行签名运算
参数:
	hSessionHandle		输入,与设备建立的会话句柄。
	uiAlgID				输入,算法类型，此参数暂不使用，接口固定使用ECC算法.
	pucPrivateKey		输入,外部ECC私钥结构.
	pucHashData			输入,缓冲区指针,用于存放外部输入的Hash数据.
	uiHashDataLength	输入,输入的数据长度.
	pucSignature		输出,缓冲区指针,用于存放输出的签名值数据.
返回值:
	返回0成功,其他值见错误码.
备注:输入数据为待签数据的杂凑值.当使用SM2算法时,该输入数据为待签数据经过SM2签名预处理的结果,预处理过程见GM/T AAAA.
*/
SGD_RV SDF_ExternalSign_ECC(SGD_HANDLE hSessionHandle, SGD_UINT32 uiAlgID, ECCrefPrivateKey *pucPrivateKey, SGD_UCHAR *pucHashData, SGD_UINT32 uiHashDataLength, ECCSignature *pucSignature);	
		
/*
外部密钥ECC验证
描述:使用外部ECC公钥对ECC签名值进行验证运算
参数:
	hSessionHandle		输入,与设备建立的会话句柄。
	uiAlgID				输入,算法类型，此参数暂不使用，接口固定使用ECC算法.
	pucPublicKey		输入,外部ECC公钥结构.
	pucHashData			输入,缓冲区指针,用于存放外部输入的Hash数据.
	uiHashDataLength	输入,输入的数据长度.
	pucSignature		输入,缓冲区指针,用于存放输入的签名值数据.
返回值:
	返回0成功,其他值见错误码.
备注:输入数据为待签数据的杂凑值.当使用SM2算法时,该输入数据为待签数据经过SM2签名预处理的结果,预处理过程见GM/T AAAA.
*/
SGD_RV SDF_ExternalVerify_ECC(SGD_HANDLE hSessionHandle, SGD_UINT32 uiAlgID, ECCrefPublicKey *pucPublicKey, SGD_UCHAR *pucHashData, SGD_UINT32 uiHashDataLength, ECCSignature *pucSignature);

/*
功能: SM2加密
参数:
	hSessionHandle		输入,会话句柄.
	uiIPKIndex			输入,索引值，取值范围0x00~0x0F,需保证索引值对应位置存在密钥；
	uiAlgID				输入,算法类型，此参数暂不使用，接口固定使用SM2算法.
	pucData				输入,要加密的数据
	uiDataLength		输入,要加密的数据的长度, 最大2048字节.
	pucEncData			输出,加密后的数据.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_InternalEncrypt_SM2(SGD_HANDLE hSessionHandle, SGD_UINT32 uiIPKIndex, SGD_UINT32 uiAlgID, SGD_UCHAR *pucData, SGD_UINT32 uiDataLength, ECCCipher *pucEncData);
	
/*
功能:SM2解密
参数:
	参数:
	hSessionHandle		输入,会话句柄.
	uiISKIndex			输入,索引值.取值范围0x00~0x0F,需保证索引值对应位置存在密钥；
	uiAlgID				输入,算法类型，此参数暂不使用，接口固定使用SM2算法.
	pucEncData			输入,要解密的数据
	pucData				输出,解密后的数据
	puiDataLength		输入/输出,输入时表示pucData的空间大小, 输出时表示解密后数据的长度.

返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_InternalDecrypt_SM2(SGD_HANDLE hSessionHandle, SGD_UINT32 uiISKIndex, SGD_UINT32 uiAlgID, ECCCipher *pucEncData, SGD_UCHAR *pucData, SGD_UINT32 *puiDataLength);
	
/*
功能: SM2签名
参数:
	hSessionHandle		输入,会话句柄.
	uiISKIndex			输入,索引值，取值范围0x00~0x0F,需保证索引值对应位置存在密钥；
	pucHashData			输入,32字节的Hash结果数据.
	uiHashDataLength	输入,pucHashData的长度,固定为32.
	pucSignature		输出,签名值,长度为64字节.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_InternalSign_SM2(SGD_HANDLE hSessionHandle, SGD_UINT32 uiISKIndex, SGD_UCHAR *pucHashData, SGD_UINT32 uiHashDataLength, ECCSignature *pucSignature);
	
/*
功能描述: SM2验签
参数:
	hSessionHandle		输入,会话句柄.
	uiISKIndex			输入,索引值，取值范围0x00~0x0F,需保证索引值对应位置存在密钥；
	pucHashData			输入,32字节Hash结果数据.
	uiHashDataLength	输入,pucHashData的长度, 固定为32.
	pucSignature		输入,64字节的签名值.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_InternalVerify_SM2(SGD_HANDLE hSessionHandle, SGD_UINT32 uiISKIndex, SGD_UCHAR *pucHashData, SGD_UINT32 uiHashDataLength, ECCSignature *pucSignature);
	
/*
外部密钥SM2公钥加密
描述:使用外部SM2公钥对数据进行加密运算
参数:
	hSessionHandle		输入,与设备建立的会话句柄。
	uiAlgID				输入,算法类型，此参数暂不使用，接口固定使用SM2算法.
	pucPublicKey		输入,外部SM2公钥结构.
	pucDataInput		输入,缓冲区指针,用于存放外部输入的数据.
	uiInputLength		输入,输入的数据长度,最大2048字节.
	pucEncData			输出,缓冲区指针,用于存放输出的数据密文.
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_ExternalEncrypt_SM2(SGD_HANDLE hSessionHandle, SGD_UINT32 uiAlgID, ECCrefPublicKey *pucPublicKey, SGD_UCHAR *pucDataInput, SGD_UINT32 uiInputLength, ECCCipher *pucEncData);	
		
/*
外部密钥SM2私钥解密
描述:使用外部SM2私钥进行解密运算
参数:
	hSessionHandle		输入,与设备建立的会话句柄。
	uiAlgID				输入,算法类型，此参数暂不使用，接口固定使用SM2算法.
	pucPrivateKey		输入,外部SM2私钥结构.
	pucEncData			输入,缓冲区指针,用于存放输入的数据密文.
	pucDataOutput		输出,缓冲区指针,用于存放输出的数据明文.
	puiOutputLength		输入/输出,入参表示pucDataOutput的空间大小,出参表示输出的数据明文长度.
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_ExternalDecrypt_SM2(SGD_HANDLE hSessionHandle, SGD_UINT32 uiAlgID, ECCrefPrivateKey *pucPrivateKey, ECCCipher *pucEncData, SGD_UCHAR *pucDataOutput, SGD_UINT32 *puiOutputLength);	
	
/*
外部密钥SM2签名
描述:使用外部SM2私钥对数据进行签名运算
参数:
	hSessionHandle		输入,与设备建立的会话句柄。
	uiAlgID				输入,算法类型，此参数暂不使用，接口固定使用SM2算法.
	pucPrivateKey		输入,外部SM2私钥结构.
	pucHashData			输入,缓冲区指针,用于存放外部输入的Hash数据.
	uiHashDataLength	输入,输入的数据长度.
	pucSignature		输出,缓冲区指针,用于存放输出的签名值数据.
返回值:
	返回0成功,其他值见错误码.
备注:输入数据为待签数据的杂凑值.当使用SM2算法时,该输入数据为待签数据经过SM2签名预处理的结果,预处理过程见GM/T AAAA.
*/
SGD_RV SDF_ExternalSign_SM2(SGD_HANDLE hSessionHandle, SGD_UINT32 uiAlgID, ECCrefPrivateKey *pucPrivateKey, SGD_UCHAR *pucHashData, SGD_UINT32 uiHashDataLength, ECCSignature *pucSignature);	
		
/*
外部密钥SM2验证
描述:使用外部SM2公钥对SM2签名值进行验证运算
参数:
	hSessionHandle		输入,与设备建立的会话句柄。
	uiAlgID				输入,算法类型，此参数暂不使用，接口固定使用SM2算法.
	pucPublicKey		输入,外部SM2公钥结构.
	pucHashData			输入,缓冲区指针,用于存放外部输入的Hash数据.
	uiHashDataLength	输入,输入的数据长度.
	pucSignature		输入,缓冲区指针,用于存放输入的签名值数据.
返回值:
	返回0成功,其他值见错误码.
备注:输入数据为待签数据的杂凑值.当使用SM2算法时,该输入数据为待签数据经过SM2签名预处理的结果,预处理过程见GM/T AAAA.
*/
SGD_RV SDF_ExternalVerify_SM2(SGD_HANDLE hSessionHandle, SGD_UINT32 uiAlgID, ECCrefPublicKey *pucPublicKey, SGD_UCHAR *pucHashData, SGD_UINT32 uiHashDataLength, ECCSignature *pucSignature);

/*
功能: RSA加密
参数:
	hSessionHandle		输入,会话句柄.
	ucKeyType			输入，密钥类型，取值：
							SGD_KEY_TYPE_RSA1024	//RSA1024
							SGD_KEY_TYPE_RSA2048	//RSA2048
	uiIPKIndex			输入,索引值，取值范围0x00~0x0F,需保证索引值对应位置存在密钥；
	pucInData			输入,缓冲区指针，存放外部输入的待加密数据，必须等于模长，且按照标准填充；
	uiInDataLength		输入,输入的数据长度，必须等于模长.
	pucOutData			输出,缓冲区指针，用于存放返回的加密后的数据.
	puiOutDataLength	输入/输出，输入时表示缓冲区大小，输出时表示返回数据的实际长度。
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_InternalEncrypt_RSA(SGD_HANDLE hSessionHandle, SGD_CHAR ucKeyType, SGD_UINT32 uiIPKIndex, SGD_UCHAR *pucInData, SGD_UINT32 uiInDataLength, SGD_UCHAR *pucOutData, SGD_UINT32 *puiOutDataLength);
	
/*
功能:RSA解密
参数:
	参数:
	hSessionHandle		输入,会话句柄.
	ucKeyType			输入，密钥类型，取值：
							SGD_KEY_TYPE_RSA1024	//RSA1024
							SGD_KEY_TYPE_RSA2048	//RSA2048
	uiISKIndex			输入,索引值.取值范围0x00~0x0F,需保证索引值对应位置存在密钥；
	pucInData			输入,缓冲区指针，存放外部输入的待解密数据；
	uiInDataLength		输入,输入的数据长度，必须等于模长.
	pucOutData			输出,缓冲区指针，用于存放返回的解密后的数据.
	puiOutDataLength	输入/输出，输入时表示缓冲区大小，输出时表示返回数据的实际长度。

返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_InternalDecrypt_RSA(SGD_HANDLE hSessionHandle, SGD_CHAR ucKeyType, SGD_UINT32 uiISKIndex, SGD_UCHAR *pucInData, SGD_UINT32 uiInDataLength, SGD_UCHAR *pucOutData, SGD_UINT32 *puiOutDataLength);
	
/*
功能: RSA签名
参数:
	hSessionHandle		输入,会话句柄.
	ucKeyType			输入，密钥类型，取值：
							SGD_KEY_TYPE_RSA1024	//RSA1024
							SGD_KEY_TYPE_RSA2048	//RSA2048
	uiISKIndex			输入,索引值，取值范围0x00~0x0F,需保证索引值对应位置存在密钥；
	pucInData			输入,缓冲区指针，存放外部输入的待签名数据，必须等于模长(数据已按照PKCS1补位) 或者 不大于 （模长 - 11），接口内对待签名数据做补位处理.
	uiInDataLength		输入,输入的数据长度，必须等于模长(数据已按照PKCS1补位) 或者 不大于 （模长 - 11），接口内对待签名数据做补位处理.
	pucOutData			输出,缓冲区指针，用于存放返回的签名值.
	puiOutDataLength	输入/输出，输入时表示缓冲区大小，输出时表示返回数据的实际长度。
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_InternalSign_RSA(SGD_HANDLE hSessionHandle, SGD_CHAR ucKeyType, SGD_UINT32 uiISKIndex, SGD_UCHAR *pucInData, SGD_UINT32 uiInDataLength, SGD_UCHAR *pucOutData, SGD_UINT32 *puiOutDataLength);
	
/*
功能描述: RSA验签
参数:
	hSessionHandle		输入,会话句柄.
	ucKeyType			输入，密钥类型，取值：
							SGD_KEY_TYPE_RSA1024	//RSA1024
							SGD_KEY_TYPE_RSA2048	//RSA2048
	uiISKIndex			输入,索引值，取值范围0x00~0x0F,需保证索引值对应位置存在密钥；
	pucHashData			输入,Hash结果数据.
	uiHashDataLength	输入,pucHashData 的长度.
	pucSignature		输入,签名值，长度必须为模长.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_InternalVerify_RSA(SGD_HANDLE hSessionHandle, SGD_CHAR ucKeyType, SGD_UINT32 uiISKIndex, SGD_UCHAR *pucHashData, SGD_UINT32 uiHashDataLength, SGD_UCHAR *pucSignature);
	
/*
外部密钥RSA公钥加密
描述:使用外部RSA公钥对数据进行加密运算
参数:
	hSessionHandle		输入,与设备建立的会话句柄。
	ucKeyType			输入，密钥类型，取值：
							SGD_KEY_TYPE_RSA1024	//RSA1024
							SGD_KEY_TYPE_RSA2048	//RSA2048
	pucRSAPublicKey		输入,外部输入的RSA公钥，格式为： E || N, 长度为132字节或260字节。
	pucInData			输入,缓冲区指针，存放外部输入的待加密数据，必须等于模长，且按照标准填充；
	uiInDataLength		输入,输入的数据长度，必须等于模长.
	pucOutData			输出,缓冲区指针，用于存放返回的加密后的数据.
	puiOutDataLength	输入/输出，输入时表示缓冲区大小，输出时表示返回数据的实际长度。
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_ExternalEncrypt_RSA(SGD_HANDLE hSessionHandle, SGD_CHAR ucKeyType,  SGD_UCHAR *pucRSAPublicKey,  SGD_UCHAR *pucInData, SGD_UINT32 uiInDataLength, SGD_UCHAR *pucOutData, SGD_UINT32 *puiOutDataLength);	
		
/*
外部密钥RSA私钥解密
描述:使用外部RSA私钥进行解密运算
参数:
	hSessionHandle		输入,与设备建立的会话句柄。
	ucKeyType			输入，密钥类型，取值：
							SGD_KEY_TYPE_RSA1024	//RSA1024
							SGD_KEY_TYPE_RSA2048	//RSA2048
	pucRSAPrivateKey	输入,外部RSA私钥内容，CRT格式，长度为320字节或640字节。
	pucInData			输入,缓冲区指针，存放外部输入的待解密数据；
	uiInDataLength		输入,输入的数据长度，必须等于模长.
	pucOutData			输出,缓冲区指针，用于存放返回的解密后的数据.
	puiOutDataLength	输入/输出，输入时表示缓冲区大小，输出时表示返回数据的实际长度。
返回值:
	返回0成功,其他值见错误码.
*/
SGD_RV SDF_ExternalDecrypt_RSA(SGD_HANDLE hSessionHandle, SGD_CHAR ucKeyType,  SGD_UCHAR *pucRSAPrivateKey, SGD_UCHAR *pucInData, SGD_UINT32 uiInDataLength, SGD_UCHAR *pucOutData, SGD_UINT32 *puiOutDataLength);
	
/*
外部密钥RSA签名
描述:使用外部RSA私钥对数据进行签名运算
参数:
	hSessionHandle		输入,与设备建立的会话句柄。
	ucKeyType			输入，密钥类型，取值：
							SGD_KEY_TYPE_RSA1024	//RSA1024
							SGD_KEY_TYPE_RSA2048	//RSA2048
	pucRSAPrivateKey		输入,外部RSA私钥结构.
	pucInData			输入,缓冲区指针，存放外部输入的待签名数据，必须等于模长(数据已按照PKCS1补位) 或者 不大于 （模长 - 11），接口内对待签名数据做补位处理.
	uiInDataLength		输入,输入的数据长度，必须等于模长(数据已按照PKCS1补位) 或者 不大于 （模长 - 11），接口内对待签名数据做补位处理.
	pucOutData			输出,缓冲区指针，用于存放返回的签名值.
	puiOutDataLength	输入/输出，输入时表示缓冲区大小，输出时表示返回数据的实际长度。
返回值:
	返回0成功,其他值见错误码.
备注:输入数据为待签数据的杂凑值.当使用RSA算法时,该输入数据为待签数据经过RSA签名预处理的结果,预处理过程见GM/T AAAA.
*/
SGD_RV SDF_ExternalSign_RSA(SGD_HANDLE hSessionHandle, SGD_CHAR ucKeyType,  SGD_UCHAR *pucRSAPrivateKey, SGD_UCHAR *pucInData, SGD_UINT32 uiInDataLength, SGD_UCHAR *pucOutData, SGD_UINT32 *puiOutDataLength);
		
/*
外部密钥RSA验证
描述:使用外部RSA公钥对RSA签名值进行验证运算
参数:
	hSessionHandle		输入,与设备建立的会话句柄。
	ucKeyType			输入，密钥类型，取值：
							SGD_KEY_TYPE_RSA1024	//RSA1024
							SGD_KEY_TYPE_RSA2048	//RSA2048
	pucRSAPublicKey		输入,外部RSA公钥结构.
	pucHashData			输入,Hash结果数据.
	uiHashDataLength	输入,pucHashData 的长度.
	pucSignature		输入,签名值，长度必须为模长.
返回值:
	返回0成功,其他值见错误码.
备注:输入数据为待签数据的杂凑值.当使用RSA算法时,该输入数据为待签数据经过RSA签名预处理的结果,预处理过程见GM/T AAAA.
*/
SGD_RV SDF_ExternalVerify_RSA(SGD_HANDLE hSessionHandle, SGD_CHAR ucKeyType,  SGD_UCHAR *pucRSAPublicKey, SGD_UCHAR *pucHashData, SGD_UINT32 uiHashDataLength, SGD_UCHAR *pucSignature);

/*
功能:初始化消息杂凑计算操作，指定计算消息杂凑的算法.
参数:
	hSessionHandle		输入,会话句柄.
	uiAlgID				输入,算法类型,当前只支持：
							SGD_SM3		
							SGD_SHA_160
							SGD_SHA_224
							SGD_SHA_256
							SGD_SHA_384
							SGD_SHA_512	
	pucPublicKey		输入,公钥数据,SM2密钥的公钥,用于获取Z值，保留参数，若不使用，传NULL即可.
	pucID				输入,用户ID,用于获取Z值，保留参数，若不使用，传NULL即可.
	uiIDLength			输入, pucID的长度，保留参数，若不使用，传0即可.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_HashInit(SGD_HANDLE hSessionHandle, SGD_UINT32 uiAlgID, ECCrefPublicKey *pucPublicKey, SGD_UCHAR *pucID, SGD_UINT32 uiIDLength);
	
/*
功能:对单一分组的消息进行杂凑计算.
参数:
	hSessionHandle		输入,会话句柄.
	pucData				输入,要处理的数据.
	uiDataLength		输入, pucData的长度,最大4064字节.
	pucHash				输出,杂凑结果缓冲区指针.
	puiHashLength		输入/输出, 输入时表示pucHash的空间大小,输出时表示返回数据pucHash的长度.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_Hash(SGD_HANDLE hSessionHandle, SGD_UCHAR *pucData, SGD_UINT32 uiDataLength, SGD_UCHAR *pucHash, SGD_UINT32 *puiHashLength);
	
/*
功能:对多个分组的消息进行杂凑计算.
参数:
	hSessionHandle		输入,会话句柄.
	pucData				输入,要处理的数据.
	uiDataLength		输入, pucData的长度,最大4064字节.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_HashUpdate(SGD_HANDLE hSessionHandle, SGD_UCHAR *pucData, SGD_UINT32 uiDataLength);

/*
功能:结束多个分组消息的杂凑计算操作，将杂凑保存到指定的缓冲区.
参数:
	 hSessionHandle		输入,会话句柄.
	 pucHash			输出,处理后的数据.
	 puiHashLength		输入/输出, 输入时表示pucHash的空间大小,输出时表示返回数据pucHash的长度.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_HashFinal(SGD_HANDLE hSessionHandle, SGD_UCHAR *pucHash, SGD_UINT32 *puiHashLength);
	
/*
功能:初始化HMAC计算操作，指定HMAC计算使用的Hash算法和密钥.
参数:
	hSessionHandle		输入,会话句柄.
	uiAlgID				输入,算法类型,保留参数，当前仅支持SM3.
	pucHMACKey			输入,计算HMAC所适应的密钥，若使用会话密钥，此参数传NULL.
	uiHMACKeyLength		输入,pucHMACKey的长度.
	uiSessionKeyID		输入,使用会话密钥计算时，此参数指定会话密钥的索引，若 pucHMACKey 参数不为空，则此参数无效.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_HMACInit(SGD_HANDLE hSessionHandle, SGD_UINT32 uiAlgID, SGD_UCHAR *pucHMACKey, SGD_UINT32 uiHMACKeyLength, SGD_UINT32 uiSessionKeyID);
	
/*
功能:对单一分组的消息进行HMAC计算.
参数:
	hSessionHandle		输入,会话句柄.
	pucData				输入,要处理的数据.
	uiDataLength		输入, pucData的长度,最大4064字节.
	pucHMAC				输出,HMAC结果缓冲区指针.
	puiHMACLength		输入/输出, 输入时表示pucHMAC的空间大小,输出时表示返回数据pucHMAC的实际长度.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_HMAC(SGD_HANDLE hSessionHandle, SGD_UCHAR *pucData, SGD_UINT32 uiDataLength, SGD_UCHAR *pucHMAC, SGD_UINT32 *puiHMACLength);
	
/*
功能:对多个分组的消息进行HMAC计算.
参数:
	hSessionHandle		输入,会话句柄.
	pucData				输入,要处理的数据.
	uiDataLength		输入, pucData的长度,最大4064字节.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_HMACUpdate(SGD_HANDLE hSessionHandle, SGD_UCHAR *pucData, SGD_UINT32 uiDataLength);

/*
功能:结束多个分组消息的HMAC计算操作，将HMAC结果保存到指定的缓冲区.
参数:
	 hSessionHandle		输入,会话句柄.
	 pucHMAC			输出,返回HMAC结果数据.
	 puiHMACLength		输入/输出, 输入时表示pucHMAC的空间大小,输出时表示返回数据pucHMAC的长度.
返回值:
	 返回SDR_OK成功,其他值失败;
*/
SGD_RV SDF_HMACFinal(SGD_HANDLE hSessionHandle, SGD_UCHAR *pucHMAC, SGD_UINT32 *puiHMACLength);

/*
功能:SM2点乘, 调用此接口前需先获取32字节随机数。
参数:
    hSessionHandle      输入,会话句柄;
    pbPointMulData      输出,指向点乘结果数据的缓冲区， 分配空间不小于64字节.
    pulDataLen          输入/输出,输入时表示pbPointMulData缓冲区长度，输出时表示结果数据实际长度。
返回值:
    返回0成功,其他值见错误码.
*/  
SGD_RV SDF_pointMul_SM2(SGD_HANDLE hSessionHandle, SGD_UCHAR *pbPointMulData, SGD_UINT32 *pulDataLen);
	
#ifdef __cplusplus
}
#endif

#endif /*#ifndef _SDF_H_*/
