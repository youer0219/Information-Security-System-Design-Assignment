#include<stdio.h>
#include <string.h>
#include"sdf.h"
#include "sm4.h"
#include<pthread.h>
#include<sys/time.h>
#include<sys/types.h>
#include <stdlib.h>
#define DEFAULT_ROOTKEY 	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
#define ROOTKEY   			"\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F\x10"
#define KPK  				"\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01"
#define FILEKEY  			"\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02"
#define DEVSN "hs_0000000000001"
#define MAX (4000)
#define LOOP (1000)
#define COUNT  100


#define SM4_ENCRYPT     1
#define SM4_DECRYPT     0
SGD_UCHAR Export_SM2PubKey[64] = { 0 };

SGD_UCHAR pubKey[64] = {
	0x8B, 0x7F, 0xB9, 0x6C, 0x09, 0x53, 0x27, 0x19, 0xE4, 0xEB, 0x79, 0x16, 0xC6, 0x2E, 0x20, 0xEA, 
	0x33, 0xCC, 0x98, 0x96, 0x43, 0xFA, 0x45, 0x09, 0x0C, 0x98, 0x4E, 0xA5, 0xDF, 0x76, 0xA1, 0xD4, 
	0xC1, 0xF8, 0x9C, 0x46, 0x67, 0x61, 0xCE, 0x07, 0x83, 0x26, 0xAF, 0x1C, 0xA0, 0x81, 0xC5, 0x89, 
	0x4E, 0x0C, 0xD5, 0x29, 0x88, 0x40, 0x96, 0x45, 0x50, 0xD9, 0x14, 0x17, 0xB7, 0x5C, 0xC5, 0x5E
};

SGD_UCHAR priKey[32] = {
	0x08, 0x3B, 0xD8, 0xEA, 0xC2, 0x20, 0xE8, 0xC5, 0x98, 0x89, 0x83, 0xB4, 0x3E, 0x07, 0x13, 0x67, 
	0xE3, 0x0C, 0x02, 0xCE, 0xA8, 0xB9, 0x19, 0x19, 0xDD, 0x7F, 0xE8, 0xB8, 0xE6, 0xDC, 0x02, 0x5B
};

SGD_UCHAR KeyPairEnc[96] = {
	0x19, 0x0e, 0x9e, 0x10, 0x5a, 0x12, 0xd5, 0x9b, 
	0xd5, 0x59, 0x5d, 0x7d, 0x06, 0xbe, 0xe0, 0x1b, 
	0x15, 0x44, 0xcc, 0x16, 0x1a, 0x34, 0xcc, 0x36, 
	0xe0, 0xbd, 0xa6, 0x83, 0x03, 0x97, 0xb5, 0x2e, 
	0x7f, 0xb5, 0x1a, 0xf6, 0x0e, 0xf9, 0xb7, 0x00, 
	0x88, 0x21, 0xdd, 0xda, 0xca, 0x2a, 0x18, 0xe9, 
	0x57, 0x49, 0xce, 0x49, 0xdc, 0x5f, 0xb9, 0x4d, 
	0xb8, 0xc8, 0x5c, 0xde, 0x96, 0xfb, 0x2b, 0x39,
	0x3a, 0x7e, 0xff, 0x53, 0x3d, 0x23, 0xd1, 0x3a,
	0xde, 0x97, 0x4b, 0xc3, 0x65, 0x3c, 0xd1, 0x43,
	0x20, 0x31, 0x98, 0xe4, 0x48, 0x7f, 0x5b, 0xc0, 
	0x01, 0xd7, 0xe9, 0x5e, 0x20, 0xfc, 0xa1, 0xc5,
};

SGD_UCHAR eccXYD[96] = {
	0x19, 0x0e, 0x9e, 0x10, 0x5a, 0x12, 0xd5, 0x9b, 
	0xd5, 0x59, 0x5d, 0x7d, 0x06, 0xbe, 0xe0, 0x1b, 
	0x15, 0x44, 0xcc, 0x16, 0x1a, 0x34, 0xcc, 0x36, 
	0xe0, 0xbd, 0xa6, 0x83, 0x03, 0x97, 0xb5, 0x2e, 
	0x7f, 0xb5, 0x1a, 0xf6, 0x0e, 0xf9, 0xb7, 0x00, 
	0x88, 0x21, 0xdd, 0xda, 0xca, 0x2a, 0x18, 0xe9, 
	0x57, 0x49, 0xce, 0x49, 0xdc, 0x5f, 0xb9, 0x4d, 
	0xb8, 0xc8, 0x5c, 0xde, 0x96, 0xfb, 0x2b, 0x39,
	0x3a, 0x7e, 0xff, 0x53, 0x3d, 0x23, 0xd1, 0x3a,
	0xde, 0x97, 0x4b, 0xc3, 0x65, 0x3c, 0xd1, 0x43,
	0x20, 0x31, 0x98, 0xe4, 0x48, 0x7f, 0x5b, 0xc0, 
	0x01, 0xd7, 0xe9, 0x5e, 0x20, 0xfc, 0xa1, 0xc5,
};

SGD_UCHAR eccXYDHash[32] = {
	0x2D ,0xEA ,0x71 ,0x6F,0x3C,0x66,0x21, 0xB8,
	0xE8 ,0x44 ,0xF6 ,0x49,0x9F,0xED,0x44, 0x27,
	0x21 ,0x06 ,0x76 ,0xF7,0xFC,0xB7,0xEB, 0x59,
	0x09 ,0x25 ,0x6C ,0xB0,0x47,0xBC,0xC7, 0x4E
};

SGD_UINT8 sm3HashData[32] = { 0 };
ECCrefPublicKey g_pucPublicKey;

void printHex(SGD_UCHAR *mark, SGD_UCHAR *pucData, SGD_UINT32 uiDataLen)
{
	printf("%s[%d]:\n", mark, uiDataLen);
	int i = 0;
	for(i = 0; i < uiDataLen; i++)
	{
		if(i != 0 && i % 4 == 0)
			printf(" ");
		if(i != 0 && i % 32 == 0)
			printf("\n");
		printf("%02x", pucData[i]);
	}
	printf("\n");
}

void printf_KeyList(SGD_UCHAR *pucData)
{
	int i = 0;
	int len = 0;
	printf("KeyList:\n");
	printf("SGD_KEY_TYPE_ROOTKEY-%02x: %02x\n",pucData[0], pucData[1]);//根密钥
	printf("SGD_KEY_TYPE_KPK-%02x: %02x\n",pucData[2], pucData[3]);//密钥保护密钥
	printf("SGD_KEY_TYPE_FILEKEY-%02x: %02x\n",pucData[4], pucData[5]);//文件密钥
	printf("SGD_KEY_TYPE_SESSIONKEY-%02x: ",pucData[6]);//会话密钥
	for(i = 1; i <= 16; i++)
	{
		printf("%02x", pucData[6 + i]);
	}
	printf("\n");
	printf("SGD_KEY_TYPE_SM2-%02x: ",pucData[23]);//SM2密钥
	for(i = 1; i <= 16; i++)
	{
		printf("%02x", pucData[23 + i]);
	}
	printf("\n");
	printf("SGD_KEY_TYPE_RSA-%02x: ",pucData[40]);//RSA密钥
	for(i = 1; i <= 32; i++)
	{
		printf("%02x", pucData[40 + i]);
	}
	printf("\n");
	printf("SGD_KEY_TYPE_ECC-%02x: ",pucData[73]);//ECC密钥
	for(i = 1; i <= 16; i++)
	{
		printf("%02x", pucData[73 + i]);
	}
	printf("\n");
}

SGD_RV SM4_ENC_DEC_ECB(SGD_HANDLE phSessionHandle)
{

	SGD_RV rv = SDR_OK;
	int loop = LOOP, i = 0;
	SGD_UCHAR pucIV[16] ={0};
	memset(pucIV, 1, 16);
	SGD_UCHAR *pucData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiDataLength = loop * MAX;
	SGD_UCHAR *pucEncData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 puiEncDataLength = loop * MAX;
	SGD_UCHAR *pucTmpData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiKeyInd = 1;
	int count = loop;
	SGD_UCHAR pucKey[16] ={0};
	SGD_UINT32 uiKeyLength = sizeof(pucKey);

	for(i = 0; i < sizeof(pucKey); i++)
	{
		pucKey[i] = i % 256;
	}
	for(i = 0; i < loop * MAX; i++)
	{
		pucData[i] = i % 256;
	}
	
	unsigned long long L1,L2,L3, L4;
	struct timeval tv;
	gettimeofday(&tv, NULL);
	L1 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	for(i = 0;i < loop; i++)
	{
		//rv = SDF_Encrypt(phSessionHandle, pucKey, uiKeyLength, uiKeyInd, SGD_SM4_ECB, pucIV, &pucData[i * MAX], MAX, &pucEncData[i * MAX], &puiEncDataLength);//使用外部传入的密钥
		rv = SDF_Encrypt(phSessionHandle, NULL, 0, uiKeyInd, SGD_SM4_ECB, pucIV, &pucData[i * MAX], MAX, &pucEncData[i * MAX], &puiEncDataLength);//使用索引指定的内部密钥
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucTmpData);
			printf("SDF_Encrypt failed rv = %08x\n", rv);
			return rv;
		}
	}
	gettimeofday(&tv, NULL);
	L2 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("SGD_SM4_ECB Encrypt datasize: %d Bytes used time: %lld us\n",loop * MAX, L2 - L1);
	printf("SGD_SM4_ECB Encrypt average speed: %d bps\n", (int)((long long)MAX*loop*8*1000000/(L2 - L1)));

	memset(pucIV,1,16);
	gettimeofday(&tv, NULL);
	L3 = tv.tv_sec*1000*1000 + tv.tv_usec;
	for(i = 0; i < loop; i++)
	{
		//rv = SDF_Decrypt(phSessionHandle, pucKey, uiKeyLength, uiKeyInd, SGD_SM4_ECB, pucIV, &pucEncData[i * MAX], MAX, &pucTmpData[i * MAX], &puiEncDataLength);
		rv = SDF_Decrypt(phSessionHandle, NULL, 0, uiKeyInd, SGD_SM4_ECB, pucIV, &pucEncData[i * MAX], MAX, &pucTmpData[i * MAX], &puiEncDataLength);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucTmpData);
			printf("SDF_Decrypt failed rv = %08x\n", rv);
			return rv;
		}
	
	}
	gettimeofday(&tv, NULL);
	L4 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	printf("SGD_SM4_ECB Decrypt datasize: %d Bytes used time: %lld us\n",loop * MAX, L4 - L3);
	printf("SGD_SM4_ECB Decrypt average speed: %d bps\n", (int)((long long)MAX*loop*8*1000000/(L4 - L3)));

	if(memcmp(pucData,pucTmpData,loop * MAX))
	{
		free(pucData);
		free(pucEncData);
		free(pucTmpData);
		printf("memcmp    diff\n");
		return -1;
	}
	free(pucData);
	free(pucEncData);
	free(pucTmpData);
	return SDR_OK;
}

SGD_RV SM4_ENC_DEC_CBC(SGD_HANDLE phSessionHandle)
{

	SGD_RV rv = SDR_OK;
	int loop = LOOP, i = 0;
	SGD_UCHAR pucIV[16] ={0};
	memset(pucIV, 1, 16);
	SGD_UCHAR *pucData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiDataLength = loop * MAX;
	SGD_UCHAR *pucEncData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 puiEncDataLength = loop * MAX;
	SGD_UCHAR *pucTmpData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiKeyInd = 1;
	int count = loop;
	SGD_UCHAR pucKey[16] ={0};
	SGD_UINT32 uiKeyLength = sizeof(pucKey);

	for(i = 0; i < sizeof(pucKey); i++)
	{
		pucKey[i] = i % 256;
	}

	for(i = 0; i < loop * MAX; i++)
	{
		pucData[i] = i % 256;
	}
	
	unsigned long long L1,L2,L3, L4;
	struct timeval tv;
	gettimeofday(&tv, NULL);
	L1 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	for(i = 0;i < loop; i++)
	{
		//rv = SDF_Encrypt(phSessionHandle, pucKey, uiKeyLength, uiKeyInd, SGD_SM4_CBC, pucIV, &pucData[i * MAX], MAX, &pucEncData[i * MAX], &puiEncDataLength);
		rv = SDF_Encrypt(phSessionHandle, NULL, 0, uiKeyInd, SGD_SM4_CBC, pucIV, &pucData[i * MAX], MAX, &pucEncData[i * MAX], &puiEncDataLength);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucTmpData);
			printf("SDF_Encrypt failed rv = %08x\n", rv);
			return rv;
		}
	}
	gettimeofday(&tv, NULL);
	L2 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("SGD_SM4_CBC Encrypt datasize: %d Bytes used time: %lld us\n",loop * MAX, L2 - L1);
	printf("SGD_SM4_CBC Encrypt average speed: %d bps\n", (int)((long long)MAX*loop*8*1000000/(L2 - L1)));

	memset(pucIV,1,16);
	gettimeofday(&tv, NULL);
	L3 = tv.tv_sec*1000*1000 + tv.tv_usec;
	for(i = 0; i < loop; i++)
	{
		//rv = SDF_Decrypt(phSessionHandle, pucKey, uiKeyLength, uiKeyInd, SGD_SM4_CBC, pucIV, &pucEncData[i * MAX], MAX, &pucTmpData[i * MAX], &puiEncDataLength);
		rv = SDF_Decrypt(phSessionHandle, NULL, 0, uiKeyInd, SGD_SM4_CBC, pucIV, &pucEncData[i * MAX], MAX, &pucTmpData[i * MAX], &puiEncDataLength);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucTmpData);
			printf("SDF_Decrypt failed rv = %08x\n", rv);
			return rv;
		}
	
	}
	gettimeofday(&tv, NULL);
	L4 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	printf("SGD_SM4_CBC Decrypt datasize: %d Bytes used time: %lld us\n",loop * MAX, L4 - L3);
	printf("SGD_SM4_CBC Decrypt average speed: %d bps\n", (int)((long long)MAX*loop*8*1000000/(L4 - L3)));

	if(memcmp(pucData,pucTmpData,loop * MAX))
	{
		free(pucData);
		free(pucEncData);
		free(pucTmpData);
		printf("memcmp    diff\n");
		return -1;
	}
	free(pucData);
	free(pucEncData);
	free(pucTmpData);
	return SDR_OK;
}

SGD_RV SM1_ENC_DEC_ECB(SGD_HANDLE phSessionHandle)
{

	SGD_RV rv = SDR_OK;
	int loop = LOOP, i = 0;
	SGD_UCHAR pucIV[16] ={0};
	memset(pucIV, 1, 16);
	SGD_UCHAR *pucData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiDataLength = loop * MAX;
	SGD_UCHAR *pucEncData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 puiEncDataLength = loop * MAX;
	SGD_UCHAR *pucTmpData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiKeyInd = 1;
	int count = loop;
	SGD_UCHAR pucKey[16] ={0};
	SGD_UINT32 uiKeyLength = sizeof(pucKey);

	for(i = 0; i < sizeof(pucKey); i++)
	{
		pucKey[i] = i % 256;
	}

	for(i = 0; i < loop * MAX; i++)
	{
		pucData[i] = i % 256;
	}
	
	unsigned long long L1,L2,L3, L4;
	struct timeval tv;
	gettimeofday(&tv, NULL);
	L1 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	for(i = 0;i < loop; i++)
	{
		//rv = SDF_Encrypt(phSessionHandle, pucKey, uiKeyLength, uiKeyInd, SGD_SM1_ECB, pucIV, &pucData[i * MAX], MAX, &pucEncData[i * MAX], &puiEncDataLength);
		rv = SDF_Encrypt(phSessionHandle, NULL, 0, uiKeyInd, SGD_SM1_ECB, pucIV, &pucData[i * MAX], MAX, &pucEncData[i * MAX], &puiEncDataLength);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucTmpData);
			return rv;
		}
	}
	gettimeofday(&tv, NULL);
	L2 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("SGD_SM1_ECB Encrypt datasize: %d Bytes used time: %lld us\n", loop * MAX, L2 - L1);
	printf("SGD_SM1_ECB Encrypt average speed: %d bps\n", (int)((long long)MAX*loop*8*1000000/(L2 - L1)));

	memset(pucIV,1,16);
	gettimeofday(&tv, NULL);
	L3 = tv.tv_sec*1000*1000 + tv.tv_usec;
	for(i = 0; i < loop; i++)
	{
		//rv = SDF_Decrypt(phSessionHandle, pucKey, uiKeyLength, uiKeyInd, SGD_SM1_ECB, pucIV, &pucEncData[i * MAX], MAX, &pucTmpData[i * MAX], &puiEncDataLength);
		rv = SDF_Decrypt(phSessionHandle, NULL, uiKeyLength, uiKeyInd, SGD_SM1_ECB, pucIV, &pucEncData[i * MAX], MAX, &pucTmpData[i * MAX], &puiEncDataLength);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucTmpData);
			return rv;
		}
	
	}
	gettimeofday(&tv, NULL);
	L4 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	printf("SGD_SM1_ECB Decrypt datasize: %d Bytes used time: %lld us\n", loop * MAX, L4 - L3);
	printf("SGD_SM1_ECB Decrypt average speed: %d bps\n", (int)((long long)MAX*loop*8*1000000/(L4 - L3)));

	if(memcmp(pucData,pucTmpData,loop * MAX))
	{
		free(pucData);
		free(pucEncData);
		free(pucTmpData);
		printf("memcmp    diff\n");
		return -1;
	}
	free(pucData);
	free(pucEncData);
	free(pucTmpData);
	return SDR_OK;
}

SGD_RV SM1_ENC_DEC_CBC(SGD_HANDLE phSessionHandle)
{

	SGD_RV rv = SDR_OK;
	int loop = LOOP, i = 0;
	SGD_UCHAR pucIV[16] ={0};
	memset(pucIV, 1, 16);
	SGD_UCHAR *pucData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiDataLength = loop * MAX;
	SGD_UCHAR *pucEncData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 puiEncDataLength = loop * MAX;
	SGD_UCHAR *pucTmpData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiKeyInd = 1;
	int count = loop;
	SGD_UCHAR pucKey[16] ={0};
	SGD_UINT32 uiKeyLength = sizeof(pucKey);

	for(i = 0; i < sizeof(pucKey); i++)
	{
		pucKey[i] = i % 256;
	}

	for(i = 0; i < loop * MAX; i++)
	{
		pucData[i] = i % 256;
	}
	
	unsigned long long L1,L2,L3, L4;
	struct timeval tv;
	gettimeofday(&tv, NULL);
	L1 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	for(i = 0;i < loop; i++)
	{
		//rv = SDF_Encrypt(phSessionHandle, pucKey, uiKeyLength, uiKeyInd, SGD_SM1_CBC, pucIV, &pucData[i * MAX], MAX, &pucEncData[i * MAX], &puiEncDataLength);
		rv = SDF_Encrypt(phSessionHandle, NULL, uiKeyLength, uiKeyInd, SGD_SM1_CBC, pucIV, &pucData[i * MAX], MAX, &pucEncData[i * MAX], &puiEncDataLength);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucTmpData);
			return rv;
		}
	}
	gettimeofday(&tv, NULL);
	L2 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("SGD_SM1_CBC Encrypt datasize: %d Bytes used time: %lld us\n",loop * MAX, L2 - L1);
	printf("SGD_SM1_CBC Encrypt average speed: %d bps\n", (int)((long long)MAX*loop*8*1000000/(L2 - L1)));

	memset(pucIV,1,16);
	gettimeofday(&tv, NULL);
	L3 = tv.tv_sec*1000*1000 + tv.tv_usec;
	for(i = 0; i < loop; i++)
	{
		//rv = SDF_Decrypt(phSessionHandle, pucKey, uiKeyLength, uiKeyInd, SGD_SM1_CBC, pucIV, &pucEncData[i * MAX], MAX, &pucTmpData[i * MAX], &puiEncDataLength);
		rv = SDF_Decrypt(phSessionHandle, NULL, 0, uiKeyInd, SGD_SM1_CBC, pucIV, &pucEncData[i * MAX], MAX, &pucTmpData[i * MAX], &puiEncDataLength);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucTmpData);
			return rv;
		}
	
	}
	gettimeofday(&tv, NULL);
	L4 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	printf("SGD_SM1_CBC Decrypt datasize: %d Bytes used time: %lld us\n",loop * MAX, L4 - L3);
	printf("SGD_SM1_CBC Decrypt average speed: %d bps\n", (int)((long long)MAX*loop*8*1000000/(L4 - L3)));

	if(memcmp(pucData,pucTmpData,loop * MAX))
	{
		free(pucData);
		free(pucEncData);
		free(pucTmpData);
		printf("memcmp    diff\n");
		return -1;
	}
	free(pucData);
	free(pucEncData);
	free(pucTmpData);
	return SDR_OK;
}

SGD_RV AES_ENC_DEC_ECB(SGD_HANDLE phSessionHandle)
{

	SGD_RV rv = SDR_OK;
	int loop = LOOP, i = 0;
	SGD_UCHAR pucIV[16] ={0};
	memset(pucIV, 1, 16);
	SGD_UCHAR *pucData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiDataLength = loop * MAX;
	SGD_UCHAR *pucEncData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 puiEncDataLength = loop * MAX;
	SGD_UCHAR *pucTmpData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiKeyInd = 1;
	int count = loop;
	SGD_UCHAR pucKey[16] ={0};
	SGD_UINT32 uiKeyLength = sizeof(pucKey);

	for(i = 0; i < sizeof(pucKey); i++)
	{
		pucKey[i] = i % 256;
	}

	for(i = 0; i < loop * MAX; i++)
	{
		pucData[i] = i % 256;
	}
	
	unsigned long long L1,L2,L3, L4;
	struct timeval tv;
	gettimeofday(&tv, NULL);
	L1 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	for(i = 0;i < loop; i++)
	{
		//rv = SDF_Encrypt(phSessionHandle, pucKey, uiKeyLength, uiKeyInd, SGD_AES_ECB, pucIV, &pucData[i * MAX], MAX, &pucEncData[i * MAX], &puiEncDataLength);
		rv = SDF_Encrypt(phSessionHandle, NULL, 0, uiKeyInd, SGD_AES_ECB, pucIV, &pucData[i * MAX], MAX, &pucEncData[i * MAX], &puiEncDataLength);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucTmpData);
			return rv;
		}
	}
	gettimeofday(&tv, NULL);
	L2 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("SGD_AES_ECB Encrypt datasize: %d Bytes used time: %lld us\n",loop * MAX, L2 - L1);
	printf("SGD_AES_ECB Encrypt average speed: %d bps\n", (int)((long long)MAX*loop*8*1000000/(L2 - L1)));

	memset(pucIV,1,16);
	gettimeofday(&tv, NULL);
	L3 = tv.tv_sec*1000*1000 + tv.tv_usec;
	for(i = 0; i < loop; i++)
	{
		//rv = SDF_Decrypt(phSessionHandle, pucKey, uiKeyLength, uiKeyInd, SGD_AES_ECB, pucIV, &pucEncData[i * MAX], MAX, &pucTmpData[i * MAX], &puiEncDataLength);
		rv = SDF_Decrypt(phSessionHandle, NULL, 0, uiKeyInd, SGD_AES_ECB, pucIV, &pucEncData[i * MAX], MAX, &pucTmpData[i * MAX], &puiEncDataLength);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucTmpData);
			return rv;
		}
	
	}
	gettimeofday(&tv, NULL);
	L4 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	printf("SGD_AES_ECB Decrypt datasize: %d Bytes used time: %lld us\n",loop * MAX, L4 - L3);
	printf("SGD_AES_ECB Decrypt average speed: %d bps\n", (int)((long long)MAX*loop*8*1000000/(L4 - L3)));

	if(memcmp(pucData,pucTmpData,loop * MAX))
	{
		free(pucData);
		free(pucEncData);
		free(pucTmpData);
		printf("memcmp    diff\n");
		return -1;
	}
	free(pucData);
	free(pucEncData);
	free(pucTmpData);
	return SDR_OK;
}

SGD_RV AES_ENC_DEC_CBC(SGD_HANDLE phSessionHandle)
{

	SGD_RV rv = SDR_OK;
	int loop = LOOP, i = 0;
	SGD_UCHAR pucIV[16] ={0};
	memset(pucIV, 1, 16);
	SGD_UCHAR *pucData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiDataLength = loop * MAX;
	SGD_UCHAR *pucEncData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 puiEncDataLength = loop * MAX;
	SGD_UCHAR *pucTmpData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiKeyInd = 1;
	int count = loop;
	SGD_UCHAR pucKey[16] ={0};
	SGD_UINT32 uiKeyLength = sizeof(pucKey);

	for(i = 0; i < sizeof(pucKey); i++)
	{
		pucKey[i] = i % 256;
	}

	for(i = 0; i < loop * MAX; i++)
	{
		pucData[i] = i % 256;
	}
	
	unsigned long long L1,L2,L3, L4;
	struct timeval tv;
	gettimeofday(&tv, NULL);
	L1 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	for(i = 0;i < loop; i++)
	{
		//rv = SDF_Encrypt(phSessionHandle, pucKey, uiKeyLength, uiKeyInd, SGD_AES_CBC, pucIV, &pucData[i * MAX], MAX, &pucEncData[i * MAX], &puiEncDataLength);
		rv = SDF_Encrypt(phSessionHandle, NULL, 0, uiKeyInd, SGD_AES_CBC, pucIV, &pucData[i * MAX], MAX, &pucEncData[i * MAX], &puiEncDataLength);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucTmpData);
			return rv;
		}
	}
	gettimeofday(&tv, NULL);
	L2 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("SGD_AES_CBC Encrypt datasize: %d Bytes used time: %lld us\n",loop * MAX, L2 - L1);
	printf("SGD_AES_CBC Encrypt average speed: %d bps\n", (int)((long long)MAX*loop*8*1000000/(L2 - L1)));

	memset(pucIV,1,16);
	gettimeofday(&tv, NULL);
	L3 = tv.tv_sec*1000*1000 + tv.tv_usec;
	for(i = 0; i < loop; i++)
	{
		//rv = SDF_Decrypt(phSessionHandle, pucKey, uiKeyLength, uiKeyInd, SGD_AES_CBC, pucIV, &pucEncData[i * MAX], MAX, &pucTmpData[i * MAX], &puiEncDataLength);
		rv = SDF_Decrypt(phSessionHandle, NULL, 0, uiKeyInd, SGD_AES_CBC, pucIV, &pucEncData[i * MAX], MAX, &pucTmpData[i * MAX], &puiEncDataLength);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucTmpData);
			return rv;
		}
	
	}
	gettimeofday(&tv, NULL);
	L4 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	printf("SGD_AES_CBC Decrypt datasize: %d Bytes used time: %lld us\n",loop * MAX, L4 - L3);
	printf("SGD_AES_CBC Decrypt average speed: %d bps\n", (int)((long long)MAX*loop*8*1000000/(L4 - L3)));

	if(memcmp(pucData,pucTmpData,loop * MAX))
	{
		free(pucData);
		free(pucEncData);
		free(pucTmpData);
		printf("memcmp    diff\n");
		return -1;
	}
	free(pucData);
	free(pucEncData);
	free(pucTmpData);
	return SDR_OK;
}

SGD_RV SM1_ENC_DEC_IPSEC(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;	
	int loop = LOOP, i = 0;
	SGD_UCHAR pucIV[16] ={0};
	memset(pucIV, 1, 16);
	SGD_UCHAR HMACKey[32] ={0};
	memset(HMACKey, 3, 32);
	SGD_UINT32 HMACKeyLen = 32;
	SGD_UCHAR *pucData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiDataLength = loop * MAX;
	SGD_UCHAR *pucEncData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiEncDataLength = loop * MAX;
	SGD_UCHAR *pucMacData = (SGD_UCHAR*)malloc(loop * 32);
	SGD_UINT32 uiMacDataLength = loop * 32;
	SGD_UCHAR *pucTmpData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UCHAR *pucTmpMacData = (SGD_UCHAR*)malloc(loop * 32);
	SGD_UCHAR sendTmpbuf[5000] = {0};
	SGD_UINT32 sendTmpbufLen = 5000;
	SGD_UCHAR recvTmpbuf[5000] = {0};
	SGD_UINT32 recvTmpbufLen = 5000;
	SGD_UCHAR ucIPhead[24] = {0};
	SGD_UINT32 uiOffset = 24;
	SGD_UCHAR ucIPheadRecv[24] = {0};
	
    SGD_UCHAR pucKey[16];
	memset(pucKey,2,16);
	if(NULL == pucData || NULL == pucEncData || NULL == pucMacData || NULL == pucTmpData || NULL == pucTmpMacData)
	{
		return SDR_MALLOCFAILED;
	}
	
	memcpy(sendTmpbuf, ucIPhead, uiOffset);
	memcpy(sendTmpbuf + uiOffset, pucIV, 16);
	for(i = 0; i < loop * MAX; i++)
	{
		pucData[i] = i % 256;
	}
	
	unsigned long long L1,L2,L3, L4;
	struct timeval tv;
	gettimeofday(&tv, NULL);
	L1 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	for(i = 0; i < loop; i++)
	{
		memcpy(sendTmpbuf + uiOffset + 16, pucData + i * MAX, MAX);
		recvTmpbufLen = uiOffset + 16 + MAX + 32;
		rv = SDF_Encrypt_IPSEC( phSessionHandle, SGD_IPSEC_SM1, pucKey, /*pucIV,*/ HMACKey, HMACKeyLen, sendTmpbuf, uiOffset + 16 + MAX, uiOffset, recvTmpbuf, &recvTmpbufLen);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucMacData);
			free(pucTmpData);
			free(pucTmpMacData);
			printf("SDF_Encrypt_IPSEC fail rv = 0x%08x\n", rv);
			return rv;
		}
		memcpy(pucEncData + i * MAX, recvTmpbuf + uiOffset + 16, MAX);
		memcpy(pucMacData + i * 32, recvTmpbuf + uiOffset + 16 + MAX, 32);
	}
	gettimeofday(&tv, NULL);
	L2 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("SGD_IPSEC_SM1 Encrypt datasize: %d Bytes used time: %lld us\n",loop * MAX, L2 - L1);
	printf("SGD_IPSEC_SM1 Encrypt average speed: %d bps\n", (int)((long long)MAX*loop*8*1000000/(L2 - L1)));

	//IV重新赋值
	memset(pucIV,1,16);

	gettimeofday(&tv, NULL);
	L3 = tv.tv_sec*1000*1000 + tv.tv_usec;
	for(i = 0; i < loop; i++)
	{
		memcpy(sendTmpbuf + uiOffset + 16, pucEncData + i * MAX, MAX);
		recvTmpbufLen = uiOffset + 16 + MAX + 32;
		rv = SDF_Decrypt_IPSEC(phSessionHandle, SGD_IPSEC_SM1, pucKey,  /*pucIV,*/ HMACKey, HMACKeyLen, sendTmpbuf, uiOffset + 16 + MAX, uiOffset, recvTmpbuf, &recvTmpbufLen);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucMacData);
			free(pucTmpData);
			free(pucTmpMacData);			
			printf("SDF_Decrypt_IPSEC fail rv = 0x%08x\n", rv);
			return rv;
		}
		memcpy(pucTmpData + i * MAX, recvTmpbuf + uiOffset + 16, MAX);
		memcpy(pucTmpMacData + i * 32, recvTmpbuf + uiOffset + 16 + MAX, 32);
	}
	gettimeofday(&tv, NULL);
	L4 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	printf("SGD_IPSEC_SM1 Decrypt datasize: %d Bytes used time: %lld us\n",loop * (MAX), L4 - L3);
	printf("SGD_IPSEC_SM1 Decrypt average speed: %d bps\n", (int)((long long)(MAX) * loop * 8 * 1000000/(L4 - L3)));

	if(memcmp(pucData,pucTmpData,loop * MAX))
	{
		free(pucData);
		free(pucEncData);
		free(pucMacData);
		free(pucTmpData);
		free(pucTmpMacData);
		printf("pucData pucTmpData  memcmp diff\n");
		return -1;
	}
	if(memcmp(pucMacData,pucTmpMacData,loop * 32))
	{
		free(pucData);
		free(pucEncData);
		free(pucMacData);
		free(pucTmpData);
		free(pucTmpMacData);
		printf("pucMacData pucTmpMacData memcmp diff\n");
		return -1;
	}
	
	free(pucData);
	free(pucEncData);
	free(pucMacData);
	free(pucTmpData);
	free(pucTmpMacData);
	return SDR_OK;
}

SGD_RV SM4_ENC_DEC_IPSEC(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;	
	int loop = LOOP, i = 0;
	SGD_UCHAR pucIV[16] ={0};
	memset(pucIV, 1, 16);
	SGD_UCHAR HMACKey[32] ={0};
	memset(HMACKey, 3, 32);
	SGD_UINT32 HMACKeyLen = 32;
	SGD_UCHAR *pucData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiDataLength = loop * MAX;
	SGD_UCHAR *pucEncData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UINT32 uiEncDataLength = loop * MAX;
	SGD_UCHAR *pucMacData = (SGD_UCHAR*)malloc(loop * 32);
	SGD_UINT32 uiMacDataLength = loop * 32;
	SGD_UCHAR *pucTmpData = (SGD_UCHAR*)malloc(loop * MAX);
	SGD_UCHAR *pucTmpMacData = (SGD_UCHAR*)malloc(loop * 32);
	SGD_UCHAR sendTmpbuf[5000] = {0};
	SGD_UINT32 sendTmpbufLen = 5000;
	SGD_UCHAR recvTmpbuf[5000] = {0};
	SGD_UINT32 recvTmpbufLen = 5000;
	SGD_UCHAR ucIPhead[24] = {0};
	SGD_UINT32 uiOffset = 24;
	SGD_UCHAR ucIPheadRecv[24] = {0};
	
    SGD_UCHAR pucKey[16];
	memset(pucKey,2,16);
	if(NULL == pucData || NULL == pucEncData || NULL == pucMacData || NULL == pucTmpData || NULL == pucTmpMacData)
	{
		return SDR_MALLOCFAILED;
	}
	
	memcpy(sendTmpbuf, ucIPhead, uiOffset);
	memcpy(sendTmpbuf + uiOffset, pucIV, 16);
	for(i = 0; i < loop * MAX; i++)
	{
		pucData[i] = i % 256;
	}
	
	unsigned long long L1,L2,L3, L4;
	struct timeval tv;
	gettimeofday(&tv, NULL);
	L1 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	for(i = 0; i < loop; i++)
	{
		memcpy(sendTmpbuf + uiOffset + 16, pucData + i * MAX, MAX);
		recvTmpbufLen = uiOffset + 16 + MAX + 32;
		rv = SDF_Encrypt_IPSEC( phSessionHandle, SGD_IPSEC_SM4, pucKey, /*pucIV,*/ HMACKey, HMACKeyLen, sendTmpbuf, uiOffset + 16 + MAX, uiOffset, recvTmpbuf, &recvTmpbufLen);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucMacData);
			free(pucTmpData);
			free(pucTmpMacData);
			printf("SDF_Encrypt_IPSEC fail rv = 0x%08x\n", rv);
			return rv;
		}
		memcpy(pucEncData + i * MAX, recvTmpbuf + uiOffset + 16, MAX);
		memcpy(pucMacData + i * 32, recvTmpbuf + uiOffset + 16 + MAX, 32);
	}
	gettimeofday(&tv, NULL);
	L2 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("SGD_IPSEC_SM4 Encrypt datasize: %d Bytes used time: %lld us\n",loop * MAX, L2 - L1);
	printf("SGD_IPSEC_SM4 Encrypt average speed: %d bps\n", (int)((long long)MAX*loop*8*1000000/(L2 - L1)));

	//IV重新赋值
	memset(pucIV,1,16);

	gettimeofday(&tv, NULL);
	L3 = tv.tv_sec*1000*1000 + tv.tv_usec;
	for(i = 0; i < loop; i++)
	{
		memcpy(sendTmpbuf + uiOffset + 16, pucEncData + i * MAX, MAX);
		recvTmpbufLen = uiOffset + 16 + MAX + 32;
		rv = SDF_Decrypt_IPSEC(phSessionHandle, SGD_IPSEC_SM4, pucKey, /*pucIV,*/ HMACKey, HMACKeyLen, sendTmpbuf, uiOffset + 16 + MAX, uiOffset, recvTmpbuf, &recvTmpbufLen);
		if(SDR_OK != rv)
		{
			free(pucData);
			free(pucEncData);
			free(pucMacData);
			free(pucTmpData);
			free(pucTmpMacData);			
			printf("SDF_Decrypt_IPSEC fail rv = 0x%08x\n", rv);
			return rv;
		}
		memcpy(pucTmpData + i * MAX, recvTmpbuf + uiOffset + 16, MAX);
		memcpy(pucTmpMacData + i * 32, recvTmpbuf + uiOffset + 16 + MAX, 32);
	}
	gettimeofday(&tv, NULL);
	L4 = tv.tv_sec*1000*1000 + tv.tv_usec;
	
	printf("SGD_IPSEC_SM4 Decrypt datasize: %d Bytes used time: %lld us\n",loop * (MAX), L4 - L3);
	printf("SGD_IPSEC_SM4 Decrypt average speed: %d bps\n", (int)((long long)(MAX) * loop * 8 * 1000000/(L4 - L3)));

	if(memcmp(pucData,pucTmpData,loop * MAX))
	{
		free(pucData);
		free(pucEncData);
		free(pucMacData);
		free(pucTmpData);
		free(pucTmpMacData);
		printf("pucData pucTmpData  memcmp diff\n");
		return -1;
	}
	if(memcmp(pucMacData,pucTmpMacData,loop * 32))
	{
		free(pucData);
		free(pucEncData);
		free(pucMacData);
		free(pucTmpData);
		free(pucTmpMacData);
		printf("pucMacData pucTmpMacData memcmp diff\n");
		return -1;
	}
	
	free(pucData);
	free(pucEncData);
	free(pucMacData);
	free(pucTmpData);
	free(pucTmpMacData);
	return SDR_OK;
}

SGD_RV ExternalAuthen(SGD_HANDLE hSessionHandle, SGD_UCHAR ucKeyType, SGD_UCHAR *pucKey)
{
	SGD_RV rv = SDR_OK;
	SGD_UCHAR pOutRand[16] = { 0 };
	SGD_UINT32 ulRandLen = 16;
	SGD_UCHAR pucAuthenData[16] = { 0 };
	sm4_context ctx;
	
	rv = SDF_GenerateRandom(hSessionHandle, pOutRand, ulRandLen);
	if(rv != SDR_OK)
	{
		printf("SDF_GenerateRandom fail, rv = 0x%08x\n", rv);
		return rv;
	}
	
	//使用指定的对称密钥加密SM2私钥得到私钥密文（此步骤在这里使用的软算法）
	sm4_setkey_enc(&ctx,pucKey);
	sm4_crypt_ecb(&ctx,SM4_ENCRYPT, 16, pOutRand, pucAuthenData);
	
	rv = SDF_ExternalAuthen(hSessionHandle, ucKeyType, pucAuthenData);
	if(rv != SDR_OK)
	{
	 	//printf("SDF_ExternalAuthen fail, rv = 0x%08x\n", rv);
	 	return rv;
	}
	printf("SDF_ExternalAuthen successed\n");
	return rv;
}

SGD_RV BinaryReadWriteTest(SGD_HANDLE hSessionHandle)
{
	SGD_UINT32 ret = 0xFFFFFFFF;
	#define LLL 16384
	SGD_UCHAR pInData[LLL + 1] = { 0 };
	SGD_UINT32 uiInDataLen = LLL;
	SGD_UCHAR pOutData[LLL + 1] = { 0 };
	SGD_UINT32 OutDataLen = LLL;
	SGD_UINT32 uiOffset = 0;
	int i = 0;
	for(i = 0; i < LLL; i++)
	{
		pInData[i] = 0x31 +  i % 9;
	}

	ret = SDF_WriteBinary(hSessionHandle, pInData, uiInDataLen, uiOffset);
	if(ret != SDR_OK)
	{
		printf("SDF_WriteBinary failed ret = 0x%08x\n", ret);
		return ret;
	}
	
	ret = SDF_ReadBinary(hSessionHandle, pOutData, OutDataLen, uiOffset);
	if(ret != SDR_OK)
	{
		printf("SDF_ReadBinary failed ret = 0x%08x\n", ret);
		return ret;
	}
	
	if(memcmp(pInData, pOutData, LLL))
	{
		printf(" Binary rw error\n");
		return 1;
	}
	//printf("Binary: %s\n", pOutData);
	return SDR_OK;
}

SGD_RV Generate_Export_Import_SM2_KeyPair(SGD_HANDLE hSessionHandle)
{
	SGD_RV rv = SDR_OK;
	int i = 0;
	SGD_UINT32 uiKeyID = 0;
	SGD_UCHAR ucUsage = 0;//SGD_KEY_USAGE_ENCRYPTION SGD_KEY_USAGE_SIGN;
	SGD_CHAR pucOutKeyPair[96] = { 0 };
	SGD_UINT32 uiKeyPairLen = 96;
	SGD_CHAR pucOutPubKey[64] = { 0 };
	SGD_UINT32 uiPubKeyLen = 64;
	SGD_CHAR pucOutPriKey[32] = { 0 };
	SGD_UINT32 uiPriKeyLen = 32;
	SGD_CHAR ucKeyContent = 0;	//SGD_Asymmetric_PUBKEY		//用于指定导入导出公钥
								//SGD_Asymmetric_PRIKEY		//用于指定导入导出私钥
								//SGD_Asymmetric_KEYPAIR	//用于指定导入导出密钥对
	
	ucUsage = SGD_KEY_USAGE_ENCRYPTION;
	//索引0~2生成加解密密钥对
	{
		for(i = 0; i < 3; i++)
		{
			uiKeyID = i;
			rv = SDF_GenerateKeyPair(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucUsage);
			if(SDR_OK != rv)
			{
				printf("SDF_GenerateKeyPair failed rv = 0x%08x\n", rv);
				return rv;
			}
		}
	}
	
	//分别导出0号公钥和私钥，并导入到3号位置
	{
		uiKeyID = 0;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 3;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//分别导出1号公钥和私钥，并导入到4号位置
	{
		memset(pucOutPubKey, 0, sizeof(pucOutPubKey));
		memset(pucOutPriKey, 0, sizeof(pucOutPriKey));
		uiPubKeyLen = sizeof(pucOutPubKey);
		uiPriKeyLen = sizeof(pucOutPriKey);

		uiKeyID = 1;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 4;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//导出2号密钥对并导入到5号位置
	{
		uiKeyID = 2;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, pucOutKeyPair, &uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 5;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, ucUsage, pucOutKeyPair, uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	ucUsage = SGD_KEY_USAGE_SIGN;
	//索引6~8生成签名验签密钥对
	{
		for(i = 6; i <= 8; i++)
		{
			uiKeyID = i;
			rv = SDF_GenerateKeyPair(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucUsage);
			if(SDR_OK != rv)
			{
				printf("SDF_GenerateKeyPair failed rv = 0x%08x\n", rv);
				return rv;
			}
		}
	}
	
	//分别导出6号公钥和私钥，并导入到9号位置
	{
		uiKeyID = 6;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		memcpy(Export_SM2PubKey, pucOutPubKey, 64);//保存到一个全局变量中，做Hash的时候会用到，不用多想。
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 9;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//分别导出7号公钥和私钥，并导入到10号位置
	{
		memset(pucOutPubKey, 0, sizeof(pucOutPubKey));
		memset(pucOutPriKey, 0, sizeof(pucOutPriKey));
		uiPubKeyLen = sizeof(pucOutPubKey);
		uiPriKeyLen = sizeof(pucOutPriKey);

		uiKeyID = 7;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 10;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//导出8号密钥对并导入到11号位置
	{
		uiKeyID = 8;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, pucOutKeyPair, &uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 11;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, ucUsage, pucOutKeyPair, uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}

	return SDR_OK;
}

SGD_RV Generate_Export_Import_ECC_KeyPair(SGD_HANDLE hSessionHandle)
{
	SGD_RV rv = SDR_OK;
	int i = 0;
	SGD_UINT32 uiKeyID = 0;
	SGD_UCHAR ucUsage = 0;//SGD_KEY_USAGE_ENCRYPTION SGD_KEY_USAGE_SIGN;
	SGD_CHAR pucOutKeyPair[96] = { 0 };
	SGD_UINT32 uiKeyPairLen = 96;
	SGD_CHAR pucOutPubKey[64] = { 0 };
	SGD_UINT32 uiPubKeyLen = 64;
	SGD_CHAR pucOutPriKey[32] = { 0 };
	SGD_UINT32 uiPriKeyLen = 32;
	SGD_CHAR ucKeyContent = 0;	//SGD_Asymmetric_PUBKEY		//用于指定导入导出公钥
								//SGD_Asymmetric_PRIKEY		//用于指定导入导出私钥
								//SGD_Asymmetric_KEYPAIR	//用于指定导入导出密钥对
	
	ucUsage = SGD_KEY_USAGE_ENCRYPTION;
	//索引0~2生成加解密密钥对
	{
		for(i = 0; i < 3; i++)
		{
			uiKeyID = i;
			rv = SDF_GenerateKeyPair(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucUsage);
			if(SDR_OK != rv)
			{
				printf("SDF_GenerateKeyPair failed rv = 0x%08x\n", rv);
				return rv;
			}
		}
	}
	
	//分别导出0号公钥和私钥，并导入到3号位置
	{
		uiKeyID = 0;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 3;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//分别导出1号公钥和私钥，并导入到4号位置
	{
		memset(pucOutPubKey, 0, sizeof(pucOutPubKey));
		memset(pucOutPriKey, 0, sizeof(pucOutPriKey));
		uiPubKeyLen = sizeof(pucOutPubKey);
		uiPriKeyLen = sizeof(pucOutPriKey);

		uiKeyID = 1;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 4;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//导出2号密钥对并导入到5号位置
	{
		uiKeyID = 2;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, pucOutKeyPair, &uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 5;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, ucUsage, pucOutKeyPair, uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	ucUsage = SGD_KEY_USAGE_SIGN;
	//索引6~8生成签名验签密钥对
	{
		for(i = 6; i <= 8; i++)
		{
			uiKeyID = i;
			rv = SDF_GenerateKeyPair(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucUsage);
			if(SDR_OK != rv)
			{
				printf("SDF_GenerateKeyPair failed rv = 0x%08x\n", rv);
				return rv;
			}
		}
	}
	
	//分别导出6号公钥和私钥，并导入到9号位置
	{
		uiKeyID = 6;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 9;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//分别导出7号公钥和私钥，并导入到10号位置
	{
		memset(pucOutPubKey, 0, sizeof(pucOutPubKey));
		memset(pucOutPriKey, 0, sizeof(pucOutPriKey));
		uiPubKeyLen = sizeof(pucOutPubKey);
		uiPriKeyLen = sizeof(pucOutPriKey);

		uiKeyID = 7;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 10;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//导出8号密钥对并导入到11号位置
	{
		uiKeyID = 8;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, pucOutKeyPair, &uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 11;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, ucUsage, pucOutKeyPair, uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}

	return SDR_OK;
}

SGD_RV Generate_Export_Import_RSA1024_KeyPair(SGD_HANDLE hSessionHandle)
{
	SGD_RV rv = SDR_OK;
	int i = 0;
	SGD_UINT32 uiKeyID = 0;
	SGD_UCHAR ucUsage = 0;//SGD_KEY_USAGE_ENCRYPTION SGD_KEY_USAGE_SIGN;
	SGD_CHAR pucOutKeyPair[452] = { 0 };
	SGD_UINT32 uiKeyPairLen = sizeof(pucOutKeyPair);
	SGD_CHAR pucOutPubKey[132] = { 0 };
	SGD_UINT32 uiPubKeyLen = sizeof(pucOutPubKey);
	SGD_CHAR pucOutPriKey[320] = { 0 };
	SGD_UINT32 uiPriKeyLen = sizeof(pucOutPriKey);
	SGD_CHAR ucKeyContent = 0;	//SGD_Asymmetric_PUBKEY		//用于指定导入导出公钥
								//SGD_Asymmetric_PRIKEY		//用于指定导入导出私钥
								//SGD_Asymmetric_KEYPAIR	//用于指定导入导出密钥对
	
	ucUsage = SGD_KEY_USAGE_ENCRYPTION;
	//索引0~2生成加解密密钥对
	{
		for(i = 0; i < 3; i++)
		{
			uiKeyID = i;
			rv = SDF_GenerateKeyPair(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucUsage);
			if(SDR_OK != rv)
			{
				printf("SDF_GenerateKeyPair failed rv = 0x%08x\n", rv);
				return rv;
			}
		}
	}
	
	//分别导出0号公钥和私钥，并导入到3号位置
	{
		uiKeyID = 0;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 3;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//分别导出1号公钥和私钥，并导入到4号位置
	{
		memset(pucOutPubKey, 0, sizeof(pucOutPubKey));
		memset(pucOutPriKey, 0, sizeof(pucOutPriKey));
		uiPubKeyLen = sizeof(pucOutPubKey);
		uiPriKeyLen = sizeof(pucOutPriKey);

		uiKeyID = 1;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 4;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//导出2号密钥对并导入到5号位置
	{
		uiKeyID = 2;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, pucOutKeyPair, &uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 5;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, ucUsage, pucOutKeyPair, uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	ucUsage = SGD_KEY_USAGE_SIGN;
	//索引6~8生成签名验签密钥对
	{
		for(i = 6; i <= 8; i++)
		{
			uiKeyID = i;
			rv = SDF_GenerateKeyPair(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucUsage);
			if(SDR_OK != rv)
			{
				printf("SDF_GenerateKeyPair failed rv = 0x%08x\n", rv);
				return rv;
			}
		}
	}
	
	//分别导出6号公钥和私钥，并导入到9号位置
	{
		uiKeyID = 6;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 9;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//分别导出7号公钥和私钥，并导入到10号位置
	{
		memset(pucOutPubKey, 0, sizeof(pucOutPubKey));
		memset(pucOutPriKey, 0, sizeof(pucOutPriKey));
		uiPubKeyLen = sizeof(pucOutPubKey);
		uiPriKeyLen = sizeof(pucOutPriKey);

		uiKeyID = 7;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 10;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//导出8号密钥对并导入到11号位置
	{
		uiKeyID = 8;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, pucOutKeyPair, &uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 11;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, ucUsage, pucOutKeyPair, uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}

	return SDR_OK;
}

SGD_RV Generate_Export_Import_RSA2048_KeyPair(SGD_HANDLE hSessionHandle)
{
	SGD_RV rv = SDR_OK;
	int i = 0;
	SGD_UINT32 uiKeyID = 0;
	SGD_UCHAR ucUsage = 0;//SGD_KEY_USAGE_ENCRYPTION SGD_KEY_USAGE_SIGN;
	SGD_CHAR pucOutKeyPair[900] = { 0 };
	SGD_UINT32 uiKeyPairLen = sizeof(pucOutKeyPair);
	SGD_CHAR pucOutPubKey[260] = { 0 };
	SGD_UINT32 uiPubKeyLen = sizeof(pucOutPubKey);
	SGD_CHAR pucOutPriKey[640] = { 0 };
	SGD_UINT32 uiPriKeyLen = sizeof(pucOutPriKey);
	SGD_CHAR ucKeyContent = 0;	//SGD_Asymmetric_PUBKEY		//用于指定导入导出公钥
								//SGD_Asymmetric_PRIKEY		//用于指定导入导出私钥
								//SGD_Asymmetric_KEYPAIR	//用于指定导入导出密钥对
	
	ucUsage = SGD_KEY_USAGE_ENCRYPTION;
	//索引0~2生成加解密密钥对
	{
		for(i = 0; i < 3; i++)
		{
			uiKeyID = i;
			rv = SDF_GenerateKeyPair(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucUsage);
			if(SDR_OK != rv)
			{
				printf("SDF_GenerateKeyPair failed rv = 0x%08x\n", rv);
				return rv;
			}
		}
	}
	
	//分别导出0号公钥和私钥，并导入到3号位置
	{
		uiKeyID = 0;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 3;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//分别导出1号公钥和私钥，并导入到4号位置
	{
		memset(pucOutPubKey, 0, sizeof(pucOutPubKey));
		memset(pucOutPriKey, 0, sizeof(pucOutPriKey));
		uiPubKeyLen = sizeof(pucOutPubKey);
		uiPriKeyLen = sizeof(pucOutPriKey);

		uiKeyID = 1;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 4;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//导出2号密钥对并导入到5号位置
	{
		uiKeyID = 2;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, pucOutKeyPair, &uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 5;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, ucUsage, pucOutKeyPair, uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	ucUsage = SGD_KEY_USAGE_SIGN;
	//索引6~8生成签名验签密钥对
	{
		for(i = 6; i <= 8; i++)
		{
			uiKeyID = i;
			rv = SDF_GenerateKeyPair(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucUsage);
			if(SDR_OK != rv)
			{
				printf("SDF_GenerateKeyPair failed rv = 0x%08x\n", rv);
				return rv;
			}
		}
	}
	
	//分别导出6号公钥和私钥，并导入到9号位置
	{
		uiKeyID = 6;
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 9;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//分别导出7号公钥和私钥，并导入到10号位置
	{
		memset(pucOutPubKey, 0, sizeof(pucOutPubKey));
		memset(pucOutPriKey, 0, sizeof(pucOutPriKey));
		uiPubKeyLen = sizeof(pucOutPubKey);
		uiPriKeyLen = sizeof(pucOutPriKey);

		uiKeyID = 7;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 10;
		ucKeyContent = SGD_Asymmetric_PRIKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, ucUsage, pucOutPriKey, uiPriKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		ucKeyContent = SGD_Asymmetric_PUBKEY;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, ucUsage, pucOutPubKey, uiPubKeyLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	//导出8号密钥对并导入到11号位置
	{
		uiKeyID = 8;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ExportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, pucOutKeyPair, &uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
		uiKeyID = 11;
		ucKeyContent = SGD_Asymmetric_KEYPAIR;
		rv = SDF_ImportAsymmetricKey(hSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, ucUsage, pucOutKeyPair, uiKeyPairLen);
		if(SDR_OK != rv)
		{
			printf("SDF_ImportAsymmetricKey failed rv = 0x%08x\n", rv);
			return rv;
		}
	}

	return SDR_OK;
}

SGD_RV SM2_Internal_EncDec(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiKeyInd = 1;
	SGD_UINT32 uiAlgID = 0;
	SGD_UCHAR pucData[32] ={0};
	SGD_UINT32 uiDataLen = sizeof(pucData);
	memset(pucData,0x05,sizeof(pucData));
	ECCCipher Cipher;
	SGD_UCHAR pucDecData[4096] ={0};
	SGD_UINT32 uiDecDataLen = sizeof(pucDecData);

	//0号密钥加密，0号密钥解密，3号密钥解密
	{
		uiKeyInd = 0;
		rv = SDF_InternalEncrypt_SM2(phSessionHandle, uiKeyInd, uiAlgID, pucData, uiDataLen, &Cipher);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalEncrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		rv = SDF_InternalDecrypt_SM2(phSessionHandle, uiKeyInd, uiAlgID, &Cipher, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDecDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 3;
		rv = SDF_InternalDecrypt_SM2(phSessionHandle, uiKeyInd, uiAlgID, &Cipher, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDecDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
	}
	//1号密钥加密，1号密钥解密，4号密钥解密
	{
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 1;
		rv = SDF_InternalEncrypt_SM2(phSessionHandle, uiKeyInd, uiAlgID, pucData, uiDataLen, &Cipher);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalEncrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		rv = SDF_InternalDecrypt_SM2(phSessionHandle, uiKeyInd, uiAlgID, &Cipher, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDecDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 4;
		rv = SDF_InternalDecrypt_SM2(phSessionHandle, uiKeyInd, uiAlgID, &Cipher, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDecDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
	}
	//2号密钥加密，2号密钥解密，5号密钥解密
	{
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 2;
		rv = SDF_InternalEncrypt_SM2(phSessionHandle, uiKeyInd, uiAlgID, pucData, uiDataLen, &Cipher);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalEncrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		rv = SDF_InternalDecrypt_SM2(phSessionHandle, uiKeyInd, uiAlgID, &Cipher, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDecDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 5;
		rv = SDF_InternalDecrypt_SM2(phSessionHandle, uiKeyInd, uiAlgID, &Cipher, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDecDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
	}
	return SDR_OK;
}

SGD_RV ECC_Internal_EncDec(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiKeyInd = 1;
	SGD_UINT32 uiAlgID = 0;
	SGD_UCHAR pucData[32] ={0};
	SGD_UINT32 uiDataLen = sizeof(pucData);
	memset(pucData,0x05,sizeof(pucData));
	ECCCipher Cipher;
	SGD_UCHAR pucDecData[4096] ={0};
	SGD_UINT32 uiDecDataLen = sizeof(pucDecData);

	//0号密钥加密，0号密钥解密，3号密钥解密
	{
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 0;
		rv = SDF_InternalEncrypt_ECC(phSessionHandle, uiKeyInd, uiAlgID, pucData, uiDataLen, &Cipher);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalEncrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		rv = SDF_InternalDecrypt_ECC(phSessionHandle, uiKeyInd, uiAlgID, &Cipher, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDecDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 3;
		rv = SDF_InternalDecrypt_ECC(phSessionHandle, uiKeyInd, uiAlgID, &Cipher, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDecDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
	}
	//1号密钥加密，1号密钥解密，4号密钥解密
	{
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 1;
		rv = SDF_InternalEncrypt_ECC(phSessionHandle, uiKeyInd, uiAlgID, pucData, uiDataLen, &Cipher);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalEncrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		rv = SDF_InternalDecrypt_ECC(phSessionHandle, uiKeyInd, uiAlgID, &Cipher, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDecDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 4;
		rv = SDF_InternalDecrypt_ECC(phSessionHandle, uiKeyInd, uiAlgID, &Cipher, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
	}
	//2号密钥加密，2号密钥解密，5号密钥解密
	{
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 2;
		rv = SDF_InternalEncrypt_ECC(phSessionHandle, uiKeyInd, uiAlgID, pucData, uiDataLen, &Cipher);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalEncrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		rv = SDF_InternalDecrypt_ECC(phSessionHandle, uiKeyInd, uiAlgID, &Cipher, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 5;
		rv = SDF_InternalDecrypt_ECC(phSessionHandle, uiKeyInd, uiAlgID, &Cipher, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_ECC failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDecDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
	}
	return SDR_OK;
}

SGD_RV RSA1024_Internal_EncDec(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiKeyInd = 1;
	SGD_UINT32 uiAlgID = 0;
	SGD_UCHAR pucData[128] ={0};
	SGD_UINT32 uiDataLen = sizeof(pucData);
	memset(pucData,0x05,sizeof(pucData));
	SGD_UCHAR pucEncData[4096] ={0};
	SGD_UINT32 uiEncDataLen = sizeof(pucEncData);
	SGD_UCHAR pucDecData[4096] ={0};
	SGD_UINT32 uiDecDataLen = sizeof(pucDecData);
	
	pucData[0] = 0x00;
	pucData[1] = 0x02;
	pucData[2] = 0xFF;
	pucData[3] = 0xFF;
	pucData[4] = 0xFF;
	pucData[5] = 0xFF;
	pucData[6] = 0xFF;
	pucData[7] = 0xFF;
	pucData[8] = 0xFF;
	pucData[9] = 0xFF;
	pucData[10] = 0x00;

	//0号密钥加密，0号密钥解密，3号密钥解密
	{
		uiKeyInd = 0;
		rv = SDF_InternalEncrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyInd, pucData, uiDataLen, pucEncData, &uiEncDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalEncrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		rv = SDF_InternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyInd, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
		
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 3;
		rv = SDF_InternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyInd, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
	}
	//1号密钥加密，1号密钥解密，4号密钥解密
	{
		uiKeyInd = 1;		
		memset(pucEncData, 0, sizeof(pucEncData));
		uiEncDataLen = sizeof(pucEncData);
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		rv = SDF_InternalEncrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyInd, pucData, uiDataLen, pucEncData, &uiEncDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalEncrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		rv = SDF_InternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyInd, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
		
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 4;
		rv = SDF_InternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyInd, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
	}
	//2号密钥加密，2号密钥解密，5号密钥解密
	{
		uiKeyInd = 2;
		memset(pucEncData, 0, sizeof(pucEncData));
		uiEncDataLen = sizeof(pucEncData);
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		rv = SDF_InternalEncrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyInd, pucData, uiDataLen, pucEncData, &uiEncDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalEncrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		rv = SDF_InternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyInd, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
		
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 5;
		rv = SDF_InternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyInd, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
	}
	return SDR_OK;
}
SGD_RV RSA2048_Internal_EncDec(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiKeyInd = 1;
	SGD_UINT32 uiAlgID = 0;
	SGD_UCHAR pucData[256] ={0};
	SGD_UINT32 uiDataLen = sizeof(pucData);
	memset(pucData,0x05,sizeof(pucData));
	SGD_UCHAR pucEncData[4096] ={0};
	SGD_UINT32 uiEncDataLen = sizeof(pucEncData);
	SGD_UCHAR pucDecData[4096] ={0};
	SGD_UINT32 uiDecDataLen = sizeof(pucDecData);

	pucData[0] = 0x00;
	pucData[1] = 0x02;
	pucData[2] = 0xFF;
	pucData[3] = 0xFF;
	pucData[4] = 0xFF;
	pucData[5] = 0xFF;
	pucData[6] = 0xFF;
	pucData[7] = 0xFF;
	pucData[8] = 0xFF;
	pucData[9] = 0xFF;
	pucData[10] = 0x00;
	
	//0号密钥加密，0号密钥解密，3号密钥解密
	{
		uiKeyInd = 0;
		rv = SDF_InternalEncrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyInd, pucData, uiDataLen, pucEncData, &uiEncDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalEncrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		rv = SDF_InternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyInd, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
		
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 3;
		rv = SDF_InternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyInd, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
	}
	//1号密钥加密，1号密钥解密，4号密钥解密
	{
		uiKeyInd = 1;		
		memset(pucEncData, 0, sizeof(pucEncData));
		uiEncDataLen = sizeof(pucEncData);
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		rv = SDF_InternalEncrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyInd, pucData, uiDataLen, pucEncData, &uiEncDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalEncrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		rv = SDF_InternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyInd, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
		
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 4;
		rv = SDF_InternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyInd, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
	}
	//2号密钥加密，2号密钥解密，5号密钥解密
	{
		uiKeyInd = 2;
		memset(pucEncData, 0, sizeof(pucEncData));
		uiEncDataLen = sizeof(pucEncData);
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		rv = SDF_InternalEncrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyInd, pucData, uiDataLen, pucEncData, &uiEncDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalEncrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		rv = SDF_InternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyInd, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
		
		memset(pucDecData, 0, sizeof(pucDecData));
		uiDecDataLen = sizeof(pucDecData);
		uiKeyInd = 5;
		rv = SDF_InternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyInd, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalDecrypt_RSA failed rv = %08x\n", rv);
			return rv;
		}
		if(memcmp(pucData,pucDecData,uiDataLen))
		{
			printf("memcpy diff \n");
			return -1;
		}
	}
	return SDR_OK;
}

SGD_RV SM2_Internal_SignVerify_test(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiISKIndex = 0;
	SGD_UCHAR pucHashData[32] = { 0 };
	SGD_UINT32 uiHashDataLength = sizeof(pucHashData);
	ECCSignature Signature ;
	int i = 0;
	unsigned long long L1,L2,L3,L4;
	struct timeval tv;
	
	//6号密钥签名，6号密钥验签
	uiISKIndex = 6;
//	rv = SDF_GenerateRandom(phSessionHandle, pucHashData, 32);
//	if(rv != SDR_OK)
//	{
//		printf("SDF_GenerateRandom fail, rv = 0x%08x\n", rv);
//		return rv;
//	}
//	printHex("pucHashData", pucHashData, 32);
//	printf("SDF_GenerateRandom successed!\n");
	
	gettimeofday(&tv, NULL);
	L1 = tv.tv_sec*1000*1000 + tv.tv_usec;
	for(i = 0; i < COUNT; i++)
	{
		rv = SDF_InternalSign_SM2(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalSign_SM2 failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	
	gettimeofday(&tv, NULL);
	L2 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("SM2-Sign Times: %d times;	Spent time: %lld us\n",COUNT, L2 - L1);
	printf("SM2-Sign average speed: %d times/s\n", (int)((long long)(COUNT*1000000)/(L2 - L1)));

	gettimeofday(&tv, NULL);
	L3 = tv.tv_sec*1000*1000 + tv.tv_usec;
	for(i = 0; i < COUNT; i++)
	{
		rv = SDF_InternalVerify_SM2(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalVerify_SM2 failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	
	gettimeofday(&tv, NULL);
	L4 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("SM2-Verify Times: %d times;	Spent time: %lld us\n",COUNT, L4 - L3);
	printf("SM2-Verify average speed: %d times/s\n", (int)( (long long)(COUNT*1000000) / (L4 - L3) ));
	
	return SDR_OK;
}
SGD_RV SM2_Internal_SignVerify(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiISKIndex = 0;
	SGD_UCHAR pucHashData[32] = { 0 };
	SGD_UINT32 uiHashDataLength = sizeof(pucHashData);
	ECCSignature Signature ;
	
	//6号密钥签名，6号密钥验签，9号密钥验签
	uiISKIndex = 6;
	rv = SDF_InternalSign_SM2(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalSign_SM2 failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	rv = SDF_InternalVerify_SM2(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_SM2 failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	uiISKIndex = 9;
	rv = SDF_InternalVerify_SM2(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_SM2 failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	//7号密钥签名，7号密钥验签，10号密钥验签
	uiISKIndex = 7;
	rv = SDF_InternalSign_SM2(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalSign_SM2 failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	rv = SDF_InternalVerify_SM2(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_SM2 failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	uiISKIndex = 10;
	rv = SDF_InternalVerify_SM2(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_SM2 failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	//8号密钥签名，8号密钥验签，11号密钥验签
	uiISKIndex = 8;
	rv = SDF_InternalSign_SM2(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalSign_SM2 failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	rv = SDF_InternalVerify_SM2(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_SM2 failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	uiISKIndex = 11;
	rv = SDF_InternalVerify_SM2(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_SM2 failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	return SDR_OK;
}

SGD_RV ECC_Internal_SignVerify(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiISKIndex = 0;
	SGD_UCHAR pucHashData[32] = { 0 };
	SGD_UINT32 uiHashDataLength = sizeof(pucHashData);
	ECCSignature Signature ;
	
	memset(pucHashData, 0x5A, sizeof(pucHashData));
	//6号密钥签名，6号密钥验签，9号密钥验签
	uiISKIndex = 6;
	rv = SDF_InternalSign_ECC(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalSign_ECC failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	rv = SDF_InternalVerify_ECC(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_ECC failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	uiISKIndex = 9;
	rv = SDF_InternalVerify_ECC(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_ECC failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	//7号密钥签名，7号密钥验签，10号密钥验签
	uiISKIndex = 7;
	rv = SDF_InternalSign_ECC(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalSign_ECC failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	rv = SDF_InternalVerify_ECC(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_ECC failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	uiISKIndex = 10;
	rv = SDF_InternalVerify_ECC(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_ECC failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	//8号密钥签名，8号密钥验签，11号密钥验签
	uiISKIndex = 8;
	rv = SDF_InternalSign_ECC(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalSign_ECC failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	rv = SDF_InternalVerify_ECC(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_ECC failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	uiISKIndex = 11;
	rv = SDF_InternalVerify_ECC(phSessionHandle, uiISKIndex, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_ECC failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	return SDR_OK;
}


SGD_RV RSA1024_Internal_SignVerify(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiISKIndex = 0;
	SGD_UCHAR pucHashData[32] = { 0 };
	SGD_UINT32 uiHashDataLength = sizeof(pucHashData);
	SGD_UCHAR pucOutData[128] = { 0 }; 
	SGD_UINT32 uiOutDataLength = sizeof(pucOutData);
	
	memset(pucHashData, 0x5A, sizeof(pucHashData));
		
	//6号密钥签名，6号密钥验签，9号密钥验签
	uiISKIndex = 6;
	rv = SDF_InternalSign_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiISKIndex, pucHashData, uiHashDataLength, pucOutData, &uiOutDataLength);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalSign_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}

	rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiISKIndex, pucHashData, uiHashDataLength, pucOutData);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	uiISKIndex = 9;
	rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiISKIndex, pucHashData, uiHashDataLength, pucOutData);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	//7号密钥签名，7号密钥验签，10号密钥验签
	memset(pucOutData, 0, sizeof(pucOutData));
	uiISKIndex = 7;
	rv = SDF_InternalSign_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiISKIndex, pucHashData, uiHashDataLength, pucOutData, &uiOutDataLength);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalSign_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiISKIndex, pucHashData, uiHashDataLength, pucOutData);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	uiISKIndex = 10;
	rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiISKIndex, pucHashData, uiHashDataLength, pucOutData);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	//8号密钥签名，8号密钥验签，11号密钥验签
	memset(pucOutData, 0, sizeof(pucOutData));
	uiISKIndex = 8;
	rv = SDF_InternalSign_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiISKIndex, pucHashData, uiHashDataLength, pucOutData, &uiOutDataLength);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalSign_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiISKIndex, pucHashData, uiHashDataLength, pucOutData);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	uiISKIndex = 11;
	rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiISKIndex, pucHashData, uiHashDataLength, pucOutData);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	return SDR_OK;
}
SGD_RV RSA2048_Internal_SignVerify(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiISKIndex = 0;
	SGD_UCHAR pucHashData[32] = { 0 };
	SGD_UINT32 uiHashDataLength = sizeof(pucHashData);
	SGD_UCHAR pucOutData[256] = { 0 }; 
	SGD_UINT32 uiOutDataLength = sizeof(pucOutData);
		
	//6号密钥签名，6号密钥验签，9号密钥验签
	uiISKIndex = 6;
	rv = SDF_InternalSign_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiISKIndex, pucHashData, uiHashDataLength, pucOutData, &uiOutDataLength);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalSign_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiISKIndex, pucHashData, uiHashDataLength, pucOutData);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	uiISKIndex = 9;
	rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiISKIndex, pucHashData, uiHashDataLength, pucOutData);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	//7号密钥签名，7号密钥验签，10号密钥验签
	memset(pucOutData, 0, sizeof(pucOutData));
	uiISKIndex = 7;
	rv = SDF_InternalSign_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiISKIndex, pucHashData, uiHashDataLength, pucOutData, &uiOutDataLength);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalSign_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiISKIndex, pucHashData, uiHashDataLength, pucOutData);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	uiISKIndex = 10;
	rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiISKIndex, pucHashData, uiHashDataLength, pucOutData);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	//8号密钥签名，8号密钥验签，11号密钥验签
	memset(pucOutData, 0, sizeof(pucOutData));
	uiISKIndex = 8;
	rv = SDF_InternalSign_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiISKIndex, pucHashData, uiHashDataLength, pucOutData, &uiOutDataLength);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalSign_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiISKIndex, pucHashData, uiHashDataLength, pucOutData);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	uiISKIndex = 11;
	rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiISKIndex, pucHashData, uiHashDataLength, pucOutData);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_RSA failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	return SDR_OK;
}

SGD_RV RSA1024_Internal_SignVerify_test(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	int i = 0;
	SGD_UINT32 uiISKIndex = 0;
	SGD_UCHAR pucHashData[32] = { 0 };
	SGD_UINT32 uiHashDataLength = sizeof(pucHashData);
	SGD_UCHAR pucOutData[128] = { 0 }; 
	SGD_UINT32 uiOutDataLength = sizeof(pucOutData);
	unsigned long long L1,L2,L3,L4;
	struct timeval tv;
	
	memset(pucHashData, 0x5A, sizeof(pucHashData));
		
	//6号密钥签名，6号密钥验签，9号密钥验签
	uiISKIndex = 6;
	gettimeofday(&tv, NULL);
	L1 = tv.tv_sec*1000*1000 + tv.tv_usec;
	for(i = 0; i < COUNT; i++)
	{
		rv = SDF_InternalSign_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiISKIndex, pucHashData, uiHashDataLength, pucOutData, &uiOutDataLength);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalSign_RSA failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	gettimeofday(&tv, NULL);
	L2 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("RSA1024-Sign Times: %d times;	Spent time: %lld us\n",COUNT, L2 - L1);
	printf("RSA1024-Sign average speed: %d times/s\n", (int)((long long)(COUNT*1000000)/(L2 - L1)));

	gettimeofday(&tv, NULL);
	L3 = tv.tv_sec*1000*1000 + tv.tv_usec;
	for(i = 0; i < COUNT; i++)
	{
		rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiISKIndex, pucHashData, uiHashDataLength, pucOutData);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalVerify_RSA failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	gettimeofday(&tv, NULL);
	L4 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("RSA1024-Verify Times: %d times;	Spent time: %lld us\n",COUNT, L4 - L3);
	printf("RSA1024-Verify average speed: %d times/s\n", (int)( (long long)(COUNT*1000000) / (L4 - L3) ));
	
	return SDR_OK;
}
SGD_RV RSA2048_Internal_SignVerify_Test(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	int i = 0;
	SGD_UINT32 uiISKIndex = 0;
	SGD_UCHAR pucHashData[32] = { 0 };
	SGD_UINT32 uiHashDataLength = sizeof(pucHashData);
	SGD_UCHAR pucOutData[256] = { 0 }; 
	SGD_UINT32 uiOutDataLength = sizeof(pucOutData);
	unsigned long long L1,L2,L3,L4;
	struct timeval tv;
		
	//6号密钥签名，6号密钥验签，9号密钥验签
	uiISKIndex = 6;
	gettimeofday(&tv, NULL);
	L1 = tv.tv_sec*1000*1000 + tv.tv_usec;
	for(i = 0; i < COUNT; i++)
	{
		rv = SDF_InternalSign_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiISKIndex, pucHashData, uiHashDataLength, pucOutData, &uiOutDataLength);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalSign_RSA failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	gettimeofday(&tv, NULL);
	L2 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("RSA2048-Sign Times: %d times;	Spent time: %lld us\n",COUNT, L2 - L1);
	printf("RSA2048-Sign average speed: %d times/s\n", (int)((long long)(COUNT*1000000)/(L2 - L1)));

	gettimeofday(&tv, NULL);
	L3 = tv.tv_sec*1000*1000 + tv.tv_usec;
	for(i = 0; i < COUNT; i++)
	{

		rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiISKIndex, pucHashData, uiHashDataLength, pucOutData);
		if(SDR_OK != rv)
		{
			printf("SDF_InternalVerify_RSA failed rv = 0x%08x\n", rv);
			return rv;
		}
	}
	gettimeofday(&tv, NULL);
	L4 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("RSA2048-Verify Times: %d times;	Spent time: %lld us\n",COUNT, L4 - L3);
	printf("RSA2048-Verify average speed: %d times/s\n", (int)( (long long)(COUNT*1000000) / (L4 - L3) ));
	
	return SDR_OK;
}

SGD_RV SM2_External_EncDec(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiAlgID = 0;
	SGD_UINT32 uiKeyID = 0;
	SGD_UCHAR ucUsage = 0;//SGD_KEY_USAGE_ENCRYPTION SGD_KEY_USAGE_SIGN;
	SGD_CHAR pucOutKeyPair[96] = { 0 };
	SGD_UINT32 uiKeyPairLen = 96;
	SGD_CHAR pucOutPubKey[64] = { 0 };
	SGD_UINT32 uiPubKeyLen = 64;
	SGD_CHAR pucOutPriKey[32] = { 0 };
	SGD_UINT32 uiPriKeyLen = 32;
	SGD_CHAR ucKeyContent = 0;	//SGD_Asymmetric_PUBKEY		//用于指定导入导出公钥
								//SGD_Asymmetric_PRIKEY		//用于指定导入导出私钥
								//SGD_Asymmetric_KEYPAIR	//用于指定导入导出密钥对
	SGD_UCHAR pucData[16] ={0};
	SGD_UINT32 uiDataLen = sizeof(pucData);
	ECCCipher Cipher;	
	ECCrefPublicKey phPubKey;
	ECCrefPrivateKey pucPrivateKey;
	SGD_UCHAR pucDecData[1025] ={0};
	SGD_UINT32 uiDecDataLen = sizeof(pucDecData);
	
	//导出0号位置的公钥和私钥
	uiKeyID = 0;
	ucKeyContent = SGD_Asymmetric_PUBKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	ucKeyContent = SGD_Asymmetric_PRIKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	
	memcpy(phPubKey.x, pucOutPubKey, 32);
	memcpy(phPubKey.y, pucOutPubKey + 32, 32);
	memcpy(pucPrivateKey.D, pucOutPriKey, 32);
	memset(pucData, 0x05, sizeof(pucData));
	
	//外部公钥加密
	rv = SDF_ExternalEncrypt_SM2(phSessionHandle, uiAlgID, &phPubKey, pucData, uiDataLen, &Cipher);	
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalEncrypt_SM2 failed rv = %08x\n", rv);
		return rv;
	}
#if 0
	printf("Cipher.clength = %d\n", Cipher.clength);
	printHex("Cipher.x", Cipher.x, 32);
	printHex("Cipher.y", Cipher.y, 32);
	printHex("Cipher.C", Cipher.C, Cipher.clength);
	printHex("Cipher.M", Cipher.M, 32);
#endif	

	//内部私钥解密
	rv = SDF_InternalDecrypt_SM2(phSessionHandle, uiKeyID, uiAlgID, &Cipher, pucDecData, &uiDecDataLen);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalDecrypt_SM2 failed rv = %08x\n", rv);
		return rv;
	}
	if(memcmp(pucData,pucDecData,uiDecDataLen))
	{
		printf("memcpy diff \n");
		return -1;
	}
	
	//外部私钥解密
	memset(pucDecData, 0, sizeof(pucDecData));
	uiDecDataLen = sizeof(pucDecData);
	rv = SDF_ExternalDecrypt_SM2(phSessionHandle, uiAlgID, &pucPrivateKey, &Cipher, pucDecData, &uiDecDataLen);	
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalDecrypt_SM2 failed rv = %08x\n", rv);
		return rv;
	}
	if(memcmp(pucData,pucDecData,uiDecDataLen))
	{
		printf("memcpy diff \n");
		return -1;
	}
	return SDR_OK;
}

SGD_RV ECC_External_EncDec(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiAlgID = 0;
	SGD_UINT32 uiKeyID = 0;
	SGD_UCHAR ucUsage = 0;//SGD_KEY_USAGE_ENCRYPTION SGD_KEY_USAGE_SIGN;
	SGD_CHAR pucOutKeyPair[96] = { 0 };
	SGD_UINT32 uiKeyPairLen = 96;
	SGD_CHAR pucOutPubKey[64] = { 0 };
	SGD_UINT32 uiPubKeyLen = 64;
	SGD_CHAR pucOutPriKey[32] = { 0 };
	SGD_UINT32 uiPriKeyLen = 32;
	SGD_CHAR ucKeyContent = 0;	//SGD_Asymmetric_PUBKEY		//用于指定导入导出公钥
								//SGD_Asymmetric_PRIKEY		//用于指定导入导出私钥
								//SGD_Asymmetric_KEYPAIR	//用于指定导入导出密钥对
	SGD_UCHAR pucData[16] ={0};
	SGD_UINT32 uiDataLen = sizeof(pucData);
	ECCCipher Cipher;	
	ECCrefPublicKey phPubKey;
	ECCrefPrivateKey pucPrivateKey;
	SGD_UCHAR pucDecData[1025] ={0};
	SGD_UINT32 uiDecDataLen = sizeof(pucDecData);
	
	//导出0号位置的公钥和私钥
	uiKeyID = 0;
	ucKeyContent = SGD_Asymmetric_PUBKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	ucKeyContent = SGD_Asymmetric_PRIKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	
	memcpy(phPubKey.x, pucOutPubKey, 32);
	memcpy(phPubKey.y, pucOutPubKey + 32, 32);
	memcpy(pucPrivateKey.D, pucOutPriKey, 32);
	memset(pucData, 0x05, sizeof(pucData));
	
	//外部公钥加密
	rv = SDF_ExternalEncrypt_ECC(phSessionHandle, uiAlgID, &phPubKey, pucData, uiDataLen, &Cipher);	
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalEncrypt_ECC failed rv = %08x\n", rv);
		return rv;
	}
#if 0
	printf("Cipher.clength = %d\n", Cipher.clength);
	printHex("Cipher.x", Cipher.x, 32);
	printHex("Cipher.y", Cipher.y, 32);
	printHex("Cipher.C", Cipher.C, Cipher.clength);
	printHex("Cipher.M", Cipher.M, 32);
#endif	

	//内部私钥解密
	rv = SDF_InternalDecrypt_ECC(phSessionHandle, uiKeyID, uiAlgID, &Cipher, pucDecData, &uiDecDataLen);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalDecrypt_ECC failed rv = %08x\n", rv);
		return rv;
	}
	if(memcmp(pucData,pucDecData,uiDecDataLen))
	{
		printf("memcpy diff \n");
		return -1;
	}
	
	//外部私钥解密
	memset(pucDecData, 0, sizeof(pucDecData));
	uiDecDataLen = sizeof(pucDecData);
	rv = SDF_ExternalDecrypt_ECC(phSessionHandle, uiAlgID, &pucPrivateKey, &Cipher, pucDecData, &uiDecDataLen);	
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalDecrypt_ECC failed rv = %08x\n", rv);
		return rv;
	}
	if(memcmp(pucData,pucDecData,uiDecDataLen))
	{
		printf("memcpy diff \n");
		return -1;
	}
	return SDR_OK;
}

SGD_RV RSA1024_External_EncDec(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiAlgID = 0;
	SGD_UINT32 uiKeyID = 0;
	SGD_UCHAR ucUsage = 0;//SGD_KEY_USAGE_ENCRYPTION SGD_KEY_USAGE_SIGN;
	SGD_CHAR pucOutKeyPair[452] = { 0 };
	SGD_UINT32 uiKeyPairLen = sizeof(pucOutKeyPair);
	SGD_CHAR pucOutPubKey[132] = { 0 };
	SGD_UINT32 uiPubKeyLen = sizeof(pucOutPubKey);
	SGD_CHAR pucOutPriKey[320] = { 0 };
	SGD_UINT32 uiPriKeyLen = sizeof(pucOutPriKey);
	SGD_CHAR ucKeyContent = 0;	//SGD_Asymmetric_PUBKEY		//用于指定导入导出公钥
								//SGD_Asymmetric_PRIKEY		//用于指定导入导出私钥
								//SGD_Asymmetric_KEYPAIR	//用于指定导入导出密钥对
	SGD_UCHAR pucData[128] ={0};
	SGD_UINT32 uiDataLen = sizeof(pucData);
	SGD_UCHAR pucEncData[128] ={0};
	SGD_UINT32 uiEncDataLen = sizeof(pucEncData);
	SGD_UCHAR pucDecData[128] ={0};
	SGD_UINT32 uiDecDataLen = sizeof(pucDecData);
	
	memset(pucData, 0x05, sizeof(pucData));
	pucData[0] = 0x00;
	pucData[1] = 0x02;
	pucData[2] = 0xFF;
	pucData[3] = 0xFF;
	pucData[4] = 0xFF;
	pucData[5] = 0xFF;
	pucData[6] = 0xFF;
	pucData[7] = 0xFF;
	pucData[8] = 0xFF;
	pucData[9] = 0xFF;
	pucData[10] = 0x00;
	
	//导出0号位置的公钥和私钥
	uiKeyID = 0;
	ucKeyContent = SGD_Asymmetric_PUBKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	ucKeyContent = SGD_Asymmetric_PRIKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
		
	//外部公钥加密
	rv = SDF_ExternalEncrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024,  pucOutPubKey,  pucData, uiDataLen, pucEncData, &uiEncDataLen);	
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalEncrypt_RSA failed rv = %08x\n", rv);
		return rv;
	}

	//内部私钥解密
	rv = SDF_InternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalDecrypt_RSA failed rv = %08x\n", rv);
		return rv;
	}
	if(memcmp(pucData,pucDecData,uiDecDataLen))
	{
		printf("memcpy diff \n");
		return -1;
	}
	
	//外部私钥解密
	memset(pucDecData, 0, sizeof(pucDecData));
	uiDecDataLen = sizeof(pucDecData);
	rv = SDF_ExternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, pucOutPriKey, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalDecrypt_RSA failed rv = %08x\n", rv);
		return rv;
	}
	if(memcmp(pucData,pucDecData,uiDecDataLen))
	{
		printf("memcpy diff \n");
		return -1;
	}
	return SDR_OK;
}

SGD_RV RSA2048_External_EncDec(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiAlgID = 0;
	SGD_UINT32 uiKeyID = 0;
	SGD_UCHAR ucUsage = 0;//SGD_KEY_USAGE_ENCRYPTION SGD_KEY_USAGE_SIGN;
	SGD_CHAR pucOutKeyPair[900] = { 0 };
	SGD_UINT32 uiKeyPairLen = sizeof(pucOutKeyPair);
	SGD_CHAR pucOutPubKey[260] = { 0 };
	SGD_UINT32 uiPubKeyLen = sizeof(pucOutPubKey);
	SGD_CHAR pucOutPriKey[640] = { 0 };
	SGD_UINT32 uiPriKeyLen = sizeof(pucOutPriKey);
	SGD_CHAR ucKeyContent = 0;	//SGD_Asymmetric_PUBKEY		//用于指定导入导出公钥
								//SGD_Asymmetric_PRIKEY		//用于指定导入导出私钥
								//SGD_Asymmetric_KEYPAIR	//用于指定导入导出密钥对
	SGD_UCHAR pucData[256] ={0};
	SGD_UINT32 uiDataLen = sizeof(pucData);
	SGD_UCHAR pucEncData[256] ={0};
	SGD_UINT32 uiEncDataLen = sizeof(pucEncData);
	SGD_UCHAR pucDecData[256] ={0};
	SGD_UINT32 uiDecDataLen = sizeof(pucDecData);
	
	memset(pucData, 0x05, sizeof(pucData));
	pucData[0] = 0x00;
	pucData[1] = 0x02;
	pucData[2] = 0xFF;
	pucData[3] = 0xFF;
	pucData[4] = 0xFF;
	pucData[5] = 0xFF;
	pucData[6] = 0xFF;
	pucData[7] = 0xFF;
	pucData[8] = 0xFF;
	pucData[9] = 0xFF;
	pucData[10] = 0x00;
	//导出0号位置的公钥和私钥
	uiKeyID = 0;
	ucKeyContent = SGD_Asymmetric_PUBKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	ucKeyContent = SGD_Asymmetric_PRIKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	//外部公钥加密
	rv = SDF_ExternalEncrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048,  pucOutPubKey,  pucData, uiDataLen, pucEncData, &uiEncDataLen);	
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalEncrypt_RSA failed rv = %08x\n", rv);
		return rv;
	}

	//内部私钥解密
	rv = SDF_InternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalDecrypt_RSA failed rv = %08x\n", rv);
		return rv;
	}
	if(memcmp(pucData,pucDecData,uiDecDataLen))
	{
		printf("memcpy diff \n");
		return -1;
	}
	
	//外部私钥解密
	memset(pucDecData, 0, sizeof(pucDecData));
	uiDecDataLen = sizeof(pucDecData);
	rv = SDF_ExternalDecrypt_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, pucOutPriKey, pucEncData, uiEncDataLen, pucDecData, &uiDecDataLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalDecrypt_RSA failed rv = %08x\n", rv);
		return rv;
	}
	if(memcmp(pucData,pucDecData,uiDecDataLen))
	{
		printf("memcpy diff \n");
		return -1;
	}
	return SDR_OK;
}
SGD_RV SM2_External_SignVerify(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiAlgID = 0;
	SGD_UINT32 uiKeyID = 0;
	SGD_CHAR pucOutKeyPair[96] = { 0 };
	SGD_UINT32 uiKeyPairLen = 96;
	SGD_CHAR pucOutPubKey[64] = { 0 };
	SGD_UINT32 uiPubKeyLen = 64;
	SGD_CHAR pucOutPriKey[32] = { 0 };
	SGD_UINT32 uiPriKeyLen = 32;
	SGD_CHAR ucKeyContent = 0;	//SGD_Asymmetric_PUBKEY		//用于指定导入导出公钥
								//SGD_Asymmetric_PRIKEY		//用于指定导入导出私钥
								//SGD_Asymmetric_KEYPAIR	//用于指定导入导出密钥对
	
	SGD_UCHAR pucHashData[32] = { 0 };
	SGD_UINT32 uiHashDataLength = sizeof(pucHashData);
	ECCSignature Signature ;
	ECCrefPublicKey phPubKey;
	ECCrefPrivateKey pucPrivateKey;
	
	//导出6号位置的公钥和私钥
	uiKeyID = 6;
	ucKeyContent = SGD_Asymmetric_PUBKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	ucKeyContent = SGD_Asymmetric_PRIKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_SM2, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	
	memcpy(phPubKey.x, pucOutPubKey, 32);
	memcpy(phPubKey.y, pucOutPubKey + 32, 32);
	memcpy(pucPrivateKey.D, pucOutPriKey, 32);
	memset(pucHashData, 0x05, sizeof(pucHashData));
	
	//外部私钥签名
	rv = SDF_ExternalSign_SM2(phSessionHandle, uiAlgID, &pucPrivateKey, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalSign_SM2 failed rv = %08x\n", rv);
		return rv;
	}

	//内部公钥验签
	rv = SDF_InternalVerify_SM2(phSessionHandle, uiKeyID, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_SM2 failed rv = %08x\n", rv);
		return rv;
	}
	
	//外部公钥验签
	rv = SDF_ExternalVerify_SM2(phSessionHandle, uiAlgID, &phPubKey, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalVerify_SM2 failed rv = %08x\n", rv);
		return rv;
	}
	return SDR_OK;
}

SGD_RV ECC_External_SignVerify(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiAlgID = 0;
	SGD_UINT32 uiKeyID = 0;
	SGD_CHAR pucOutKeyPair[96] = { 0 };
	SGD_UINT32 uiKeyPairLen = 96;
	SGD_CHAR pucOutPubKey[64] = { 0 };
	SGD_UINT32 uiPubKeyLen = 64;
	SGD_CHAR pucOutPriKey[32] = { 0 };
	SGD_UINT32 uiPriKeyLen = 32;
	SGD_CHAR ucKeyContent = 0;	//SGD_Asymmetric_PUBKEY		//用于指定导入导出公钥
								//SGD_Asymmetric_PRIKEY		//用于指定导入导出私钥
								//SGD_Asymmetric_KEYPAIR	//用于指定导入导出密钥对
	
	SGD_UCHAR pucHashData[32] = { 0 };
	SGD_UINT32 uiHashDataLength = sizeof(pucHashData);
	ECCSignature Signature ;
	ECCrefPublicKey phPubKey;
	ECCrefPrivateKey pucPrivateKey;
	
	//导出6号位置的公钥和私钥
	uiKeyID = 6;
	ucKeyContent = SGD_Asymmetric_PUBKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	ucKeyContent = SGD_Asymmetric_PRIKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_ECC, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	
	memcpy(phPubKey.x, pucOutPubKey, 32);
	memcpy(phPubKey.y, pucOutPubKey + 32, 32);
	memcpy(pucPrivateKey.D, pucOutPriKey, 32);
	memset(pucHashData, 0x05, sizeof(pucHashData));
	
	//外部私钥签名
	rv = SDF_ExternalSign_ECC(phSessionHandle, uiAlgID, &pucPrivateKey, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalSign_ECC failed rv = %08x\n", rv);
		return rv;
	}

	//内部公钥验签
	rv = SDF_InternalVerify_ECC(phSessionHandle, uiKeyID, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_ECC failed rv = %08x\n", rv);
		return rv;
	}
	
	//外部公钥验签
	rv = SDF_ExternalVerify_ECC(phSessionHandle, uiAlgID, &phPubKey, pucHashData, uiHashDataLength, &Signature);
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalVerify_ECC failed rv = %08x\n", rv);
		return rv;
	}
	return SDR_OK;
}

SGD_RV RSA1024_External_SignVerify(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiAlgID = 0;
	SGD_UINT32 uiKeyID = 0;
	SGD_CHAR pucOutKeyPair[452] = { 0 };
	SGD_UINT32 uiKeyPairLen = sizeof(pucOutKeyPair);
	SGD_CHAR pucOutPubKey[132] = { 0 };
	SGD_UINT32 uiPubKeyLen = sizeof(pucOutPubKey);
	SGD_CHAR pucOutPriKey[320] = { 0 };
	SGD_UINT32 uiPriKeyLen = sizeof(pucOutPriKey);
	SGD_CHAR ucKeyContent = 0;	//SGD_Asymmetric_PUBKEY		//用于指定导入导出公钥
								//SGD_Asymmetric_PRIKEY		//用于指定导入导出私钥
								//SGD_Asymmetric_KEYPAIR	//用于指定导入导出密钥对
	
	SGD_UCHAR pucHashData[32] = { 0 };
	SGD_UINT32 uiHashDataLength = sizeof(pucHashData);
	SGD_UCHAR pucSignature[128] = { 0 };
	SGD_UINT32 uiSignatureLength = sizeof(pucSignature);
	
	memset(pucHashData, 0x05, sizeof(pucHashData));	
	
	//导出6号位置的公钥和私钥
	uiKeyID = 6;
	ucKeyContent = SGD_Asymmetric_PUBKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	ucKeyContent = SGD_Asymmetric_PRIKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	//外部私钥签名
	rv = SDF_ExternalSign_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024,  pucOutPriKey, pucHashData, uiHashDataLength, pucSignature, &uiSignatureLength);
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalSign_RSA failed rv = %08x\n", rv);
		return rv;
	}

	//内部公钥验签
	rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, uiKeyID, pucHashData, uiHashDataLength, pucSignature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_RSA failed rv = %08x\n", rv);
		return rv;
	}
	
	//外部公钥验签
	rv = SDF_ExternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA1024, pucOutPubKey, pucHashData, uiHashDataLength, pucSignature);
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalVerify_RSA failed rv = %08x\n", rv);
		return rv;
	}
	return SDR_OK;
}

SGD_RV RSA2048_External_SignVerify(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiAlgID = 0;
	SGD_UINT32 uiKeyID = 0;
	SGD_CHAR pucOutKeyPair[900] = { 0 };
	SGD_UINT32 uiKeyPairLen = sizeof(pucOutKeyPair);
	SGD_CHAR pucOutPubKey[260] = { 0 };
	SGD_UINT32 uiPubKeyLen = sizeof(pucOutPubKey);
	SGD_CHAR pucOutPriKey[640] = { 0 };
	SGD_UINT32 uiPriKeyLen = sizeof(pucOutPriKey);
	SGD_CHAR ucKeyContent = 0;	//SGD_Asymmetric_PUBKEY		//用于指定导入导出公钥
								//SGD_Asymmetric_PRIKEY		//用于指定导入导出私钥
								//SGD_Asymmetric_KEYPAIR	//用于指定导入导出密钥对
	
	SGD_UCHAR pucHashData[32] = { 0 };
	SGD_UINT32 uiHashDataLength = sizeof(pucHashData);
	SGD_UCHAR pucSignature[256] = { 0 };
	SGD_UINT32 uiSignatureLength = sizeof(pucSignature);
	
	memset(pucHashData, 0x05, sizeof(pucHashData));
	
	//导出6号位置的公钥和私钥
	uiKeyID = 6;
	ucKeyContent = SGD_Asymmetric_PUBKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, pucOutPubKey, &uiPubKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	ucKeyContent = SGD_Asymmetric_PRIKEY;
	rv = SDF_ExportAsymmetricKey(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, ucKeyContent, pucOutPriKey, &uiPriKeyLen);
	if(SDR_OK != rv)
	{
		printf("SDF_ExportAsymmetricKey failed rv = 0x%08x\n", rv);
		return rv;
	}
	
	
	//外部私钥签名
	rv = SDF_ExternalSign_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048,  pucOutPriKey, pucHashData, uiHashDataLength, pucSignature, &uiSignatureLength);
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalSign_RSA failed rv = %08x\n", rv);
		return rv;
	}

	//内部公钥验签
	rv = SDF_InternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, uiKeyID, pucHashData, uiHashDataLength, pucSignature);
	if(SDR_OK != rv)
	{
		printf("SDF_InternalVerify_RSA failed rv = %08x\n", rv);
		return rv;
	}
	
	//外部公钥验签
	rv = SDF_ExternalVerify_RSA(phSessionHandle, SGD_KEY_TYPE_RSA2048, pucOutPubKey, pucHashData, uiHashDataLength, pucSignature);
	if(SDR_OK != rv)
	{
		printf("SDF_ExternalVerify_RSA failed rv = %08x\n", rv);
		return rv;
	}
	return SDR_OK;
}

SGD_RV SGD_SM3Hash(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;//sm3HashData
	SGD_UINT32 loop = LOOP;
	SGD_UINT32 count = loop;
	ECCrefPublicKey ucPublicKey;
	SGD_UCHAR  pucID[16] = {0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08};
	SGD_UINT32 uiIDLen = 16;
	SGD_UINT8 pucData[4000] ={0};
	SGD_UINT32 uiPucDateLen = sizeof(pucData);
	SGD_UINT8 pucHashData_1[32] ={0};
	SGD_UINT32 uiHashData_1Len = sizeof(pucHashData_1);
	SGD_UINT8 pucHashData_2[32] ={0};
	SGD_UINT32 uiHashData_2Len = sizeof(pucHashData_2);
	unsigned long long L1,L2,L3,L4;
	struct timeval tv;
	
	memset(pucData, 0x05, sizeof(pucData));
	memcpy(ucPublicKey.x, Export_SM2PubKey, 32);
	memcpy(ucPublicKey.y, Export_SM2PubKey + 32, 32);
	
	//单组Hash测试
	rv = SDF_HashInit(phSessionHandle, SGD_SM3, &ucPublicKey, pucID, uiIDLen);
	if(SDR_OK != rv)
	{
		printf("SDF_HashInit failed rv = %08x\n", rv);
		return rv;
	}

	rv = SDF_Hash(phSessionHandle, pucData, uiPucDateLen, pucHashData_1, &uiHashData_1Len);
	if(SDR_OK != rv)
	{
		printf("SDF_Hash failed rv = %08x\n", rv);
		return rv;
	}

	//多组Hash测试
	rv = SDF_HashInit(phSessionHandle, SGD_SM3, &ucPublicKey, pucID, uiIDLen);
	if(SDR_OK != rv)
	{
		printf("SDF_HashInit failed rv = %08x\n", rv);
		return rv;
	}

	rv = SDF_HashUpdate(phSessionHandle, pucData, uiPucDateLen / 2);
	if(SDR_OK != rv)
	{
		printf("SDF_HashUpdate failed rv = %08x\n", rv);
		return rv;
	}

	rv = SDF_HashUpdate(phSessionHandle, pucData + (uiPucDateLen / 2), uiPucDateLen / 2);
	if(SDR_OK != rv)
	{
		printf("SDF_HashUpdate failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_HashFinal(phSessionHandle, pucHashData_2, &uiHashData_2Len);
	if(SDR_OK != rv)
	{
		printf("SDF_HashFinal failed rv = %08x\n", rv);
		return rv;
	}
	
	if(memcmp(pucHashData_1, pucHashData_2, uiHashData_1Len))
	{
		printf("HashData    diff\n");
		printHex("pucHashData_1", pucHashData_1, uiHashData_1Len);
		printHex("pucHashData_2", pucHashData_2, uiHashData_1Len);
		return -1;
	}
	//性能测试
	gettimeofday(&tv, NULL);
	L1 = tv.tv_sec*1000*1000 + tv.tv_usec;
	rv = SDF_HashInit(phSessionHandle, SGD_SM3, NULL, NULL, 0);
	if(SDR_OK != rv)
	{
		printf("SDF_HashInit failed rv = 0x%08x\n", rv);
		return rv;
	}
	while(count--)
	{
		rv = SDF_HashUpdate(phSessionHandle, pucData, uiPucDateLen);
		if(SDR_OK != rv)
		{
			printf("SDF_HashUpdate failed rv = 0x%08x\n", rv);
			return rv;
		}	
	}
	
	rv = SDF_HashFinal(phSessionHandle, pucHashData_1, &uiHashData_1Len);
	if(SDR_OK != rv)
	{
		printf("SDF_HashFinal failed rv = 0x%08x\n", rv);
		return rv;
	}	
	
	gettimeofday(&tv, NULL);
	L2 = tv.tv_sec*1000*1000 + tv.tv_usec;
	printf("The amount of data: %d bytes time: %lld us\n",uiPucDateLen * loop, L2 - L1);
	printf("SGD_SM3Hash average speed: %d bps\n", (int)((long long)uiPucDateLen * loop *8*1000000/(L2 - L1)));

	return SDR_OK;
}
SGD_RV SGD_SHA_160_Hash(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT8 pucData[4000] ={0};
	SGD_UINT32 uiPucDateLen = sizeof(pucData);
	SGD_UINT8 pucHashData_1[20] ={0};
	SGD_UINT32 uiHashData_1Len = sizeof(pucHashData_1);
	SGD_UINT8 pucHashData_2[20] ={0};
	SGD_UINT32 uiHashData_2Len = sizeof(pucHashData_2);
	
	memset(pucData, 0x05, sizeof(pucData));

	//单组Hash测试
	rv = SDF_HashInit(phSessionHandle, SGD_SHA_160, NULL, NULL, 0);
	if(SDR_OK != rv)
	{
		printf("SDF_HashInit failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_Hash(phSessionHandle, pucData, uiPucDateLen, pucHashData_1, &uiHashData_1Len);
	if(SDR_OK != rv)
	{
		printf("SDF_Hash failed rv = %08x\n", rv);
		return rv;
	}

	//多组Hash测试
	rv = SDF_HashInit(phSessionHandle, SGD_SHA_160, NULL, NULL, 0);
	if(SDR_OK != rv)
	{
		printf("SDF_HashInit failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_HashUpdate(phSessionHandle, pucData, uiPucDateLen / 2);
	if(SDR_OK != rv)
	{
		printf("SDF_HashUpdate failed rv = %08x\n", rv);
		return rv;
	}
	rv = SDF_HashUpdate(phSessionHandle, pucData + (uiPucDateLen / 2), uiPucDateLen / 2);
	if(SDR_OK != rv)
	{
		printf("SDF_HashUpdate failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_HashFinal(phSessionHandle, pucHashData_2, &uiHashData_2Len);
	if(SDR_OK != rv)
	{
		printf("SDF_HashFinal failed rv = %08x\n", rv);
		return rv;
	}
	
	if(memcmp(pucHashData_1, pucHashData_2, uiHashData_1Len))
	{
		printf("HashData    diff\n");
		return -1;
	}

	return SDR_OK;
}

SGD_RV SGD_SHA_224_Hash(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT8 pucData[4000] ={0};
	SGD_UINT32 uiPucDateLen = sizeof(pucData);
	SGD_UINT8 pucHashData_1[28] ={0};
	SGD_UINT32 uiHashData_1Len = sizeof(pucHashData_1);
	SGD_UINT8 pucHashData_2[28] ={0};
	SGD_UINT32 uiHashData_2Len = sizeof(pucHashData_2);
	
	memset(pucData, 0x05, sizeof(pucData));

	//单组Hash测试
	rv = SDF_HashInit(phSessionHandle, SGD_SHA_224, NULL, NULL, 0);
	if(SDR_OK != rv)
	{
		printf("SDF_HashInit failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_Hash(phSessionHandle, pucData, uiPucDateLen, pucHashData_1, &uiHashData_1Len);
	if(SDR_OK != rv)
	{
		printf("SDF_Hash failed rv = %08x\n", rv);
		return rv;
	}

	//多组Hash测试
	rv = SDF_HashInit(phSessionHandle, SGD_SHA_224, NULL, NULL, 0);
	if(SDR_OK != rv)
	{
		printf("SDF_HashInit failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_HashUpdate(phSessionHandle, pucData, uiPucDateLen / 2);
	if(SDR_OK != rv)
	{
		printf("SDF_HashUpdate failed rv = %08x\n", rv);
		return rv;
	}
	rv = SDF_HashUpdate(phSessionHandle, pucData + (uiPucDateLen / 2), uiPucDateLen / 2);
	if(SDR_OK != rv)
	{
		printf("SDF_HashUpdate failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_HashFinal(phSessionHandle, pucHashData_2, &uiHashData_2Len);
	if(SDR_OK != rv)
	{
		printf("SDF_HashFinal failed rv = %08x\n", rv);
		return rv;
	}
	
	if(memcmp(pucHashData_1, pucHashData_2, uiHashData_1Len))
	{
		printf("HashData    diff\n");
		return -1;
	}

	return SDR_OK;
}

SGD_RV SGD_SHA_256_Hash(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT8 pucData[4000] ={0};
	SGD_UINT32 uiPucDateLen = sizeof(pucData);
	SGD_UINT8 pucHashData_1[32] ={0};
	SGD_UINT32 uiHashData_1Len = sizeof(pucHashData_1);
	SGD_UINT8 pucHashData_2[32] ={0};
	SGD_UINT32 uiHashData_2Len = sizeof(pucHashData_2);
	
	memset(pucData, 0x05, sizeof(pucData));

	//单组Hash测试
	rv = SDF_HashInit(phSessionHandle, SGD_SHA_256, NULL, NULL, 0);
	if(SDR_OK != rv)
	{
		printf("SDF_HashInit failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_Hash(phSessionHandle, pucData, uiPucDateLen, pucHashData_1, &uiHashData_1Len);
	if(SDR_OK != rv)
	{
		printf("SDF_Hash failed rv = %08x\n", rv);
		return rv;
	}

	//多组Hash测试
	rv = SDF_HashInit(phSessionHandle, SGD_SHA_256, NULL, NULL, 0);
	if(SDR_OK != rv)
	{
		printf("SDF_HashInit failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_HashUpdate(phSessionHandle, pucData, uiPucDateLen / 2);
	if(SDR_OK != rv)
	{
		printf("SDF_HashUpdate failed rv = %08x\n", rv);
		return rv;
	}
	rv = SDF_HashUpdate(phSessionHandle, pucData + (uiPucDateLen / 2), uiPucDateLen / 2);
	if(SDR_OK != rv)
	{
		printf("SDF_HashUpdate failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_HashFinal(phSessionHandle, pucHashData_2, &uiHashData_2Len);
	if(SDR_OK != rv)
	{
		printf("SDF_HashFinal failed rv = %08x\n", rv);
		return rv;
	}
	
	if(memcmp(pucHashData_1, pucHashData_2, uiHashData_1Len))
	{
		printf("HashData    diff\n");
		return -1;
	}

	return SDR_OK;
}

SGD_RV SGD_SHA_384_Hash(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT8 pucData[4000] ={0};
	SGD_UINT32 uiPucDateLen = sizeof(pucData);
	SGD_UINT8 pucHashData_1[48] ={0};
	SGD_UINT32 uiHashData_1Len = sizeof(pucHashData_1);
	SGD_UINT8 pucHashData_2[48] ={0};
	SGD_UINT32 uiHashData_2Len = sizeof(pucHashData_2);
	
	memset(pucData, 0x05, sizeof(pucData));

	//单组Hash测试
	rv = SDF_HashInit(phSessionHandle, SGD_SHA_384, NULL, NULL, 0);
	if(SDR_OK != rv)
	{
		printf("SDF_HashInit failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_Hash(phSessionHandle, pucData, uiPucDateLen, pucHashData_1, &uiHashData_1Len);
	if(SDR_OK != rv)
	{
		printf("SDF_Hash failed rv = %08x\n", rv);
		return rv;
	}

	//多组Hash测试
	rv = SDF_HashInit(phSessionHandle, SGD_SHA_384, NULL, NULL, 0);
	if(SDR_OK != rv)
	{
		printf("SDF_HashInit failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_HashUpdate(phSessionHandle, pucData, uiPucDateLen / 2);
	if(SDR_OK != rv)
	{
		printf("SDF_HashUpdate failed rv = %08x\n", rv);
		return rv;
	}
	rv = SDF_HashUpdate(phSessionHandle, pucData + (uiPucDateLen / 2), uiPucDateLen / 2);
	if(SDR_OK != rv)
	{
		printf("SDF_HashUpdate failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_HashFinal(phSessionHandle, pucHashData_2, &uiHashData_2Len);
	if(SDR_OK != rv)
	{
		printf("SDF_HashFinal failed rv = %08x\n", rv);
		return rv;
	}
	
	if(memcmp(pucHashData_1, pucHashData_2, uiHashData_1Len))
	{
		printf("HashData    diff\n");
		return -1;
	}

	return SDR_OK;
}

SGD_RV SGD_SHA_512_Hash(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT8 pucData[4000] ={0};
	SGD_UINT32 uiPucDateLen = sizeof(pucData);
	SGD_UINT8 pucHashData_1[64] ={0};
	SGD_UINT32 uiHashData_1Len = sizeof(pucHashData_1);
	SGD_UINT8 pucHashData_2[64] ={0};
	SGD_UINT32 uiHashData_2Len = sizeof(pucHashData_2);
	
	memset(pucData, 0x05, sizeof(pucData));

	//单组Hash测试
	rv = SDF_HashInit(phSessionHandle, SGD_SHA_512, NULL, NULL, 0);
	if(SDR_OK != rv)
	{
		printf("SDF_HashInit failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_Hash(phSessionHandle, pucData, uiPucDateLen, pucHashData_1, &uiHashData_1Len);
	if(SDR_OK != rv)
	{
		printf("SDF_Hash failed rv = %08x\n", rv);
		return rv;
	}

	//多组Hash测试
	rv = SDF_HashInit(phSessionHandle, SGD_SHA_512, NULL, NULL, 0);
	if(SDR_OK != rv)
	{
		printf("SDF_HashInit failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_HashUpdate(phSessionHandle, pucData, uiPucDateLen / 2);
	if(SDR_OK != rv)
	{
		printf("SDF_HashUpdate failed rv = %08x\n", rv);
		return rv;
	}
	rv = SDF_HashUpdate(phSessionHandle, pucData + (uiPucDateLen / 2), uiPucDateLen / 2);
	if(SDR_OK != rv)
	{
		printf("SDF_HashUpdate failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_HashFinal(phSessionHandle, pucHashData_2, &uiHashData_2Len);
	if(SDR_OK != rv)
	{
		printf("SDF_HashFinal failed rv = %08x\n", rv);
		return rv;
	}
	
	if(memcmp(pucHashData_1, pucHashData_2, uiHashData_1Len))
	{
		printf("HashData    diff\n");
		return -1;
	}

	return SDR_OK;
}


SGD_RV SGD_HMac(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT32 uiAlgID = 0;
	SGD_UINT8 pucData[4000] ={0};
	SGD_UINT32 uiPucDateLen = sizeof(pucData);
	SGD_UINT8 pucHMACData_1[32] ={0};
	SGD_UINT32 uiHMACData_1Len = sizeof(pucHMACData_1);
	SGD_UINT8 pucHMACData_2[32] ={0};
	SGD_UINT32 uiHMACData_2Len = sizeof(pucHMACData_2);
	
	memset(pucData, 0x05, sizeof(pucData));

	//单组HMAC测试
	rv = SDF_HMACInit(phSessionHandle, uiAlgID, NULL, 0, 0);
	if(SDR_OK != rv)
	{
		printf("SDF_HMACInit failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_HMAC(phSessionHandle, pucData, uiPucDateLen, pucHMACData_1, &uiHMACData_1Len);
	if(SDR_OK != rv)
	{
		printf("SDF_HMAC failed rv = %08x\n", rv);
		return rv;
	}

	//多组HMAC测试
	rv = SDF_HMACInit(phSessionHandle, uiAlgID, NULL, 0, 0);
	if(SDR_OK != rv)
	{
		printf("SDF_HMACInit failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_HMACUpdate(phSessionHandle, pucData, uiPucDateLen / 2);
	if(SDR_OK != rv)
	{
		printf("SDF_HMACUpdate failed rv = %08x\n", rv);
		return rv;
	}
	rv = SDF_HMACUpdate(phSessionHandle, pucData + (uiPucDateLen / 2), uiPucDateLen / 2);
	if(SDR_OK != rv)
	{
		printf("SDF_HMACUpdate failed rv = %08x\n", rv);
		return rv;
	}
	
	rv = SDF_HMACFinal(phSessionHandle, pucHMACData_2, &uiHMACData_2Len);
	if(SDR_OK != rv)
	{
		printf("SDF_HMACFinal failed rv = %08x\n", rv);
		return rv;
	}
	
	if(memcmp(pucHMACData_1, pucHMACData_2, uiHMACData_1Len))
	{
		printf("HMACData    diff\n");
		return -1;
	}

	return SDR_OK;
}

SGD_RV pointMul_SM2(SGD_HANDLE phSessionHandle)
{
	SGD_RV rv = SDR_OK;
	SGD_UINT8 pucRandData[32] ={0};
	SGD_UINT32 uiRandLen = sizeof(pucRandData);
	SGD_UCHAR pbPointMulData[64] = { 0 };
	SGD_UINT32 ulDataLen = sizeof(pbPointMulData);
	
//	rv = SDF_GenerateRandom(phSessionHandle, pucRandData, uiRandLen);
//	if(SDR_OK != rv)
//	{
//		printf("SDF_GenerateRandom failed rv = %08x\n", rv);
//		return rv;
//	}
	
	rv = SDF_pointMul_SM2(phSessionHandle, pbPointMulData, &ulDataLen);
	if(SDR_OK != rv)
	{
		printf("SDF_pointMul_SM2 failed rv = %08x\n", rv);
		return rv;
	}
	printHex("pbPointMulData", pbPointMulData, ulDataLen);
	return SDR_OK;
}


int main(int argc, char *argv[])
{
	SGD_RV rv = 0;
	int i = 0;
	int num = 1;
	SGD_HANDLE phDeviceHandle;
	SGD_HANDLE phSessionHandle;
	SGD_UCHAR DevNamelist[256] = {0};
	SGD_UINT32 DevNameListLen = sizeof(DevNamelist);
	SGD_UINT32 DevNum = 0;
	SGD_UCHAR pucKeyList[256] = { 0 };
	SGD_UINT32 uiKeyListLen = sizeof(pucKeyList);
	SGD_UCHAR pOutRand[256] = { 0 };
	SGD_UINT32 ulRandLen = 16;
	SGD_UCHAR DevSN[64] = { 0 };
	SGD_UINT32 uiDevSNLen = sizeof(DevSN);
	SGD_UCHAR CosVer[10] = { 0 };
	SGD_UCHAR pucChipID[64] = { 0 };
	SGD_UINT32 uiChipIDLen = sizeof(pucChipID);
	SGD_UCHAR ucReadPermission = 0x00;
	SGD_UCHAR ucWritePermission = 0x00;
	SGD_UINT32 uiKeyInd = 0;
	SGD_UCHAR pucKey[16] = { 0 };
	SGD_UINT32 uiKeyLength = 16;
	
	int loop = 1;
	if (argc > 1)
	{
		loop = atol(argv[1]);
		//num = atol(argv[1]);
	}
	
#if 0
	rv = SDF_EnumDev(DevNamelist, &DevNameListLen, &DevNum);
	if(DevNum == 0)
	{
		printf("设备未插入\n");
		return 0;
	}
	if(rv != SDR_OK)
	{
		printf("HSF_EnumDev failed\n");
		return 0;
	}
	else
	{
		printf("HSF_EnumDev succeed\n");
	}
	printf("找到%d个设备\n", DevNum);	

	char *NamelistTmp = DevNamelist;
	for(i = 1; i <= DevNum; i++)
	{
		printf("设备%d: %s\n", i, NamelistTmp);
	    NamelistTmp += strlen(NamelistTmp) + 1;
	}
	
	printf("请选择要连接的设备，输入1-%d:", DevNum);
	while(1)
	{
		scanf("%d",&num);
		getchar();
		if(!(num >= 1 && num <= DevNum))
		{
			printf("输入错误\n");
			printf("请选择要连接的设备，输入1-%d:", DevNum);
			continue;
		}
		break;
	}
	NamelistTmp = DevNamelist;
	for(i = 0; i < num; i++)
	{
	    NamelistTmp += (i == 0 ? 0 : 1) * (strlen(NamelistTmp) + 1);
	}


	printf("要连接的设备名：%s\n",NamelistTmp);
	

	rv = SDF_ConnectDevicesByName(NamelistTmp, &phDeviceHandle);
	
	if(rv != SDR_OK)
	{
		printf("HSF_ConnectDevicesByName failed\n");
		return 0;
	}
	else
	{
		printf("HSF_ConnectDevicesByName success\n");
	}

#else
	rv = SDF_OpenDevice(&phDeviceHandle);
	if(rv != SDR_OK)
	{
		printf("open devces fail rv = 0x%08x\n", rv);
		return 0;
	}
	printf("open device successed!\n");
#endif
	
	
	rv = SDF_OpenSession(phDeviceHandle, &phSessionHandle);
	if(rv != SDR_OK)
	{
		SDF_CloseDevice(phDeviceHandle);
		printf("open session fail rv = 0x%08x\n", rv);
		return 0;
	}
	printf("open session successed!\n");

	rv = SDF_GetCosVersion(phSessionHandle, CosVer);
	if(rv != SDR_OK)
	{
	 	printf("SDF_GetCosVersion fail, rv = 0x%08x\n", rv);
	 	goto err;
	}                                                               
	printf("CosVer: %s\n", CosVer);
	printf("SDF_GetCosVersion successed\n");

	rv = SDF_GetChipID(phSessionHandle, pucChipID, &uiChipIDLen);
	if(rv != SDR_OK)
	{
	 	printf("SDF_GetChipID fail, rv = 0x%08x\n", rv);
	 	goto err;
	}
	printHex("pucChipID", pucChipID, uiChipIDLen);
	printf("SDF_GetChipID successed\n");

	rv = SDF_GetKeyList(phSessionHandle, pucKeyList, &uiKeyListLen);
	if(rv != SDR_OK)
	{
	 	printf("SDF_GetKeyList fail, rv = 0x%08x\n", rv);
	 	goto err;
	}
	printf_KeyList(pucKeyList);
	printf("SDF_GetKeyList successed\n");

	rv = SDF_GenerateRandom(phSessionHandle, pOutRand, ulRandLen);
	if(rv != SDR_OK)
	{
		printf("SDF_GenerateRandom fail, rv = 0x%08x\n", rv);
		goto err;
	}
	printHex("pOutRand", pOutRand, ulRandLen);
	printf("SDF_GenerateRandom successed!\n");
	
	//外部认证根密钥
	//认证默认根密钥
	rv = ExternalAuthen(phSessionHandle, SGD_KEY_TYPE_ROOTKEY, (SGD_UINT8 *)DEFAULT_ROOTKEY);
	if(rv != SDR_OK)//认证默认根密钥失败则认证修改后的根密钥
	{
		rv = ExternalAuthen(phSessionHandle, SGD_KEY_TYPE_ROOTKEY, (SGD_UINT8 *)ROOTKEY);
		if(rv != SDR_OK)
		{
			printf("ExternalAuthen fail, rv = 0x%08x\n", rv);
			goto err;
		}
	}
	else//认证默认根密钥成功，则修改根密钥
	{
		printf("ExternalAuthen rootkey successed!\n");
		//修改根密钥
		rv = SDF_ImportManagerialKey(phSessionHandle, SGD_KEY_TYPE_ROOTKEY, (SGD_UINT8 *)ROOTKEY);
		if(rv != SDR_OK)
		{
			printf("SDF_ImportManagerialKey fail, rv = 0x%08x\n", rv);
			goto err;
		}
		printf("SDF_ImportManagerialKey rootkey successed!\n");
	}
	
	//导入(修改)密钥保护密钥
	rv = SDF_ImportManagerialKey(phSessionHandle, SGD_KEY_TYPE_KPK, (SGD_UINT8 *)KPK);
	if(rv != SDR_OK)
	{
		printf("SDF_ImportManagerialKey SGD_KEY_TYPE_KPK fail, rv = 0x%08x\n", rv);
		goto err;
	}
	printf("SDF_ImportManagerialKey SGD_KEY_TYPE_KPK successed!\n");
	
	//导入(修改)文件密钥
	rv = SDF_ImportManagerialKey(phSessionHandle, SGD_KEY_TYPE_FILEKEY, (SGD_UINT8 *)FILEKEY);
	if(rv != SDR_OK)
	{
		printf("SDF_ImportManagerialKey SGD_KEY_TYPE_FILEKEY fail, rv = 0x%08x\n", rv);
		goto err;
	}
	printf("SDF_ImportManagerialKey SGD_KEY_TYPE_FILEKEY successed!\n");
	
	//导入设备序列号，仅能导入一次
	rv = SDF_InstallDeviceSN(phSessionHandle, (SGD_UINT8 *)DEVSN,16);	
	if(rv != SDR_OK)
	{
		printf("SDF_InstallDeviceSN fail, DEVSN can only import once rv = 0x%08x\n", rv);
		//goto err;
	}
	printf("SDF_InstallDeviceSN successed!\n");
	
	memset(pucKeyList, 0, sizeof(pucKeyList));
	rv = SDF_GetKeyList(phSessionHandle, pucKeyList, &uiKeyListLen);
	if(rv != SDR_OK)
	{
	 	printf("SDF_GetKeyList fail, rv = 0x%08x\n", rv);
	 	goto err;
	}
	printf_KeyList(pucKeyList);
	printf("SDF_GetKeyList successed\n");
	
	rv = SDF_GetDeviceSN(phSessionHandle, DevSN, &uiDevSNLen);
	if(rv != SDR_OK)
	{
	 	printf("SDF_GetDeviceSN fail, rv = 0x%08x\n", rv);
	 	goto err;
	}
	printf("DevSN:%s\n",DevSN);
	printf("SDF_GetDeviceSN successed\n");
	
	//对文件密钥进行外部认证
	rv = ExternalAuthen(phSessionHandle, SGD_KEY_TYPE_FILEKEY, (SGD_UINT8 *)FILEKEY);
	if(rv != SDR_OK)
	{
		printf("ExternalAuthen SGD_KEY_TYPE_FILEKEY fail, rv = 0x%08x\n", rv);
	 	goto err;
	}
	printf("ExternalAuthen SGD_KEY_TYPE_FILEKEY successed!\n");
	
	//设置芯片内二进制数据区的读写权限，执行此操作前需进行文件密钥的外部认证。
	ucReadPermission = 0x00; 
	ucWritePermission = 0x00;
	rv = SDF_ConfigDataAreaPermission(phSessionHandle, ucReadPermission, ucWritePermission);
	if(rv != SDR_OK)
	{
	 	printf("SDF_ConfigDataAreaPermission fail, rv = 0x%08x\n", rv);
	 	goto err;
	}
	printf("SDF_ConfigDataAreaPermission successed\n");
	
	//读写二进制数据区域
	rv = BinaryReadWriteTest(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("BinaryReadWriteTest fail\n");
		goto err;
	}
	printf("BinaryReadWriteTest success!\n");
	
	for(i = 0; i < sizeof(pucKey); i++)
	{
		pucKey[i] = i % 256;
	}
	
	//导入会话密钥
	for(i = 0; i < 16; i++)
	{
		uiKeyInd = i;
		//memset(pucKey, i, uiKeyLength);
		rv = SDF_ImportSessionKey(phSessionHandle, uiKeyInd, pucKey, uiKeyLength);	
		if(rv != SDR_OK)
		{
			printf("SDF_ImportSessionKey fail, rv = 0x%08x\n", rv);
			goto err;
		}
	}	
	printf("SDF_ImportSessionKey success!\n");
	
	//获取密钥列表
	memset(pucKeyList, 0, sizeof(pucKeyList));
	rv = SDF_GetKeyList(phSessionHandle, pucKeyList, &uiKeyListLen);
	if(rv != SDR_OK)
	{
	 	printf("SDF_GetKeyList fail, rv = 0x%08x\n", rv);
	 	goto err;
	}
	printf_KeyList(pucKeyList);
	printf("SDF_GetKeyList successed\n");

	//删除会话密钥
	for(i = 8; i < 16; i++)
	{
		uiKeyInd = i;
		rv = SDF_DestroySessionKey(phSessionHandle, uiKeyInd);
		if(rv != SDR_OK)
		{
			printf("SDF_DestroySessionKey fail, rv = 0x%08x\n", rv);
			goto err;
		}
	}	
	printf("SDF_DestroySessionKey success!\n");
	
	//获取密钥列表
	memset(pucKeyList, 0, sizeof(pucKeyList));
	rv = SDF_GetKeyList(phSessionHandle, pucKeyList, &uiKeyListLen);
	if(rv != SDR_OK)
	{
	 	printf("SDF_GetKeyList fail, rv = 0x%08x\n", rv);
	 	goto err;
	}
	printf_KeyList(pucKeyList);
	printf("SDF_GetKeyList successed line %d\n", __LINE__);
#if 1
	//一系列的对称算法加解密
	rv = SM4_ENC_DEC_ECB(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SM4_ENC_DEC_ECB fail\n");
		goto err;
	}
	
	rv = SM4_ENC_DEC_CBC(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SM4_ENC_DEC_CBC fail\n");
		goto err;
	}

	rv = SM1_ENC_DEC_ECB(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SM1_ENC_DEC_ECB fail\n");
		goto err;
	}

	rv = SM1_ENC_DEC_CBC(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SM1_ENC_DEC_CBC fail\n");
		goto err;
	}

	rv = AES_ENC_DEC_ECB(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("AES_ENC_DEC_ECB fail\n");
		goto err;
	}
	
	rv = AES_ENC_DEC_CBC(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("AES_ENC_DEC_CBC fail\n");
		goto err;
	}
#endif	
	//IPSEC 接口测试
	rv =SM1_ENC_DEC_IPSEC(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SM1_ENC_DEC_IPSEC fail\n");
		goto err;
	}

	rv =SM4_ENC_DEC_IPSEC(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SM4_ENC_DEC_IPSEC fail\n");
		goto err;
	}
	
	//对密钥保护密钥进行外部认证
	rv = ExternalAuthen(phSessionHandle, SGD_KEY_TYPE_KPK, (SGD_UINT8 *)KPK);
	if(rv != SDR_OK)
	{
		printf("ExternalAuthen SGD_KEY_TYPE_FILEKEY fail, rv = 0x%08x\n", rv);
	 	goto err;
	}
	printf("ExternalAuthen SGD_KEY_TYPE_KPK successed!\n");
	
	//产生、导出、导入密钥测试项
	rv =Generate_Export_Import_SM2_KeyPair(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("Generate_Export_Import_SM2_KeyPair fail\n");
		goto err;
	}
	printf("Generate_Export_Import_SM2_KeyPair successed!\n");
	
	rv =Generate_Export_Import_ECC_KeyPair(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("Generate_Export_Import_ECC_KeyPair fail\n");
		goto err;
	}
	printf("Generate_Export_Import_ECC_KeyPair successed!\n");
	
	rv =Generate_Export_Import_RSA1024_KeyPair(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("Generate_Export_Import_RSA1024_KeyPair fail\n");
		goto err;
	}
	printf("Generate_Export_Import_RSA1024_KeyPair successed!\n");
	
	rv = Generate_Export_Import_RSA2048_KeyPair(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("Generate_Export_Import_RSA2048_KeyPair fail\n");
		goto err;
	}
	printf("Generate_Export_Import_RSA2048_KeyPair successed!\n");
	
	//获取密钥列表
	memset(pucKeyList, 0, sizeof(pucKeyList));
	rv = SDF_GetKeyList(phSessionHandle, pucKeyList, &uiKeyListLen);
	if(rv != SDR_OK)
	{
	 	printf("SDF_GetKeyList fail, rv = 0x%08x\n", rv);
	 	goto err;
	}
	printf_KeyList(pucKeyList);
	printf("SDF_GetKeyList successed\n");

	rv = SM2_Internal_EncDec(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SM2_Internal_EncDec fail\n");
		goto err;
	}
	printf("SM2_Internal_EncDec successed!\n");
	
	rv = ECC_Internal_EncDec(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("ECC_Internal_EncDec fail\n");
		goto err;
	}
	printf("ECC_Internal_EncDec successed!\n");
	
	rv = RSA1024_Internal_EncDec(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("RSA1024_Internal_EncDec fail\n");
		goto err;
	}
	printf("RSA1024_Internal_EncDec successed!\n");
	
	rv = RSA2048_Internal_EncDec(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("RSA2048_Internal_EncDec fail\n");
		goto err;
	}
	printf("RSA2048_Internal_EncDec successed!\n");
	
	rv = SM2_Internal_SignVerify(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SM2_Internal_SignVerify fail\n");
		goto err;
	}
	printf("SM2_Internal_SignVerify successed!\n");
	
	rv = SM2_Internal_SignVerify_test(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SM2_Internal_SignVerify_test fail\n");
		goto err;
	}
	printf("SM2_Internal_SignVerify_test successed!\n");
	
	
	
	rv = ECC_Internal_SignVerify(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("ECC_Internal_SignVerify fail\n");
		goto err;
	}
	printf("ECC_Internal_SignVerify successed!\n");
	
	rv = RSA1024_Internal_SignVerify(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("RSA1024_Internal_SignVerify fail\n");
		goto err;
	}
	printf("RSA1024_Internal_SignVerify successed!\n");

	rv = RSA2048_Internal_SignVerify(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("RSA2048_Internal_SignVerify fail\n");
		goto err;
	}
	printf("RSA2048_Internal_SignVerify successed!\n");	
	
	rv = RSA1024_Internal_SignVerify_test(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("RSA1024_Internal_SignVerify_test fail\n");
		goto err;
	}
	printf("RSA1024_Internal_SignVerify_test successed!\n");
	
	rv = RSA2048_Internal_SignVerify_Test(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("RSA2048_Internal_SignVerify_Test fail\n");
		goto err;
	}
	printf("RSA2048_Internal_SignVerify_Test successed!\n");
	
	
	rv = SM2_External_EncDec(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SM2_External_EncDec fail\n");
		goto err;
	}
	printf("SM2_External_EncDec successed!\n");
	
	rv = ECC_External_EncDec(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("ECC_External_EncDec fail\n");
		goto err;
	}
	printf("ECC_External_EncDec successed!\n");
	
	rv = RSA1024_External_EncDec(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("RSA1024_External_EncDec fail\n");
		goto err;
	}
	printf("RSA1024_External_EncDec successed!\n");
	
	rv = RSA2048_External_EncDec(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("RSA2048_External_EncDec fail\n");
		goto err;
	}
	printf("RSA2048_External_EncDec successed!\n");
	
	rv = SM2_External_SignVerify(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SM2_External_SignVerify fail\n");
		goto err;
	}
	printf("SM2_External_SignVerify successed!\n");
	
	rv = ECC_External_SignVerify(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("ECC_External_SignVerify fail\n");
		goto err;
	}
	printf("ECC_External_SignVerify successed!\n");
	
	rv = RSA1024_External_SignVerify(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("RSA1024_External_SignVerify fail\n");
		goto err;
	}
	printf("RSA1024_External_SignVerify successed!\n");
	
	rv = RSA2048_External_SignVerify(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("RSA2048_External_SignVerify fail\n");
		goto err;
	}
	printf("RSA2048_External_SignVerify successed!\n");
	
	rv = SGD_SM3Hash(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SGD_SM3Hash fail\n");
		goto err;
	}
	printf("SGD_SM3Hash successed!\n");
	
	rv = SGD_SHA_160_Hash(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SGD_SHA_160_Hash fail\n");
		goto err;
	}
	printf("SGD_SHA_160_Hash successed!\n");
	
	rv = SGD_SHA_224_Hash(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SGD_SHA_224_Hash fail\n");
		goto err;
	}
	printf("SGD_SHA_224_Hash successed!\n");
	
	rv = SGD_SHA_256_Hash(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SGD_SHA_256_Hash fail\n");
		goto err;
	}
	printf("SGD_SHA_256_Hash successed!\n");
	
	rv = SGD_SHA_384_Hash(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SGD_SHA_384_Hash fail\n");
		goto err;
	}
	printf("SGD_SHA_384_Hash successed!\n");
	
	rv = SGD_SHA_512_Hash(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SGD_SHA_512_Hash fail\n");
		goto err;
	}
	printf("SGD_SHA_512_Hash successed!\n");
	
	rv = SGD_HMac(phSessionHandle);
	if(rv != SDR_OK)
	{
		printf("SGD_HMac fail\n");
		goto err;
	}
	printf("SGD_HMac successed!\n");
	
	
	
end:
	SDF_CloseSession(phSessionHandle);
    SDF_CloseDevice(phDeviceHandle);
	printf("test successed.\n");
	return 0;
err:
	SDF_CloseSession(phSessionHandle);
    SDF_CloseDevice(phDeviceHandle);
	printf("test failed.\n");

	return -1;
}

